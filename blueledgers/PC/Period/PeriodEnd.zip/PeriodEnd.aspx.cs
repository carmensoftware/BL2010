using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using BlueLedger.PL.BaseClass;

namespace BlueLedger.PL.PC
{
    public partial class PeriodEnd : BasePage
    {
        private readonly Blue.BL.PC.Priod period = new Blue.BL.PC.Priod();
        private DataSet dsPeriod = new DataSet();

        protected override void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Page_Retrieve();
            }
            else
            {
                dsPeriod = (DataSet)Session["dsPeriod"];
            }

            base.Page_Load(sender, e);
        }

        private void Page_Retrieve()
        {
            dsPeriod.Clear();

            var getLatestOpenPeriod = period.GetLatestOpen(dsPeriod, LoginInfo.ConnStr);

            if (!getLatestOpenPeriod)
            {
                return;
            }
            Session["dsPeriod"] = dsPeriod;
            Page_Setting();
        }

        private void Page_Setting()
        {
            if (dsPeriod.Tables[period.TableName].Rows.Count > 0)
            {
                var drPeriod = dsPeriod.Tables[period.TableName].Rows[0];
                string endDate = DateTime.Parse(drPeriod["EndDate"].ToString()).ToString(LoginInfo.BuFmtInfo.FmtSDate);
                lbl_EndDate.Text = endDate;
                endDate = DateTime.Parse(drPeriod["EndDate"].ToString()).ToString("yyyy-MM-dd");

                GetEOPListByEndDate(endDate);
                SetStatusTable();
                gvStoreList.DataSource = dsPeriod.Tables[1];
                gvStoreList.DataBind();
            }

            if (dsPeriod.Tables[period.TableName].Rows.Count > 0)
            {
                var drPeriod = dsPeriod.Tables[period.TableName].Rows[0];
                var result = period.CheckEndDate(DateTime.Parse(drPeriod["EndDate"].ToString()), LoginInfo.ConnStr);

                btn_OK.Enabled = true;
                if (!result)
                {
                    btn_OK.Enabled = false;
                    btn_OK.CssClass = "btnDisable";
                }
            }
        }

        protected void GetEOPListByEndDate(string endDate)
        {
            string connection = LoginInfo.ConnStr;
            SqlConnection cnn = new SqlConnection(connection);
            try { cnn.Open(); }
            catch { cnn.Close(); }
            string strSqlList = "SELECT Sto.LocationCode, Sto.LocationName, EOP.[Status] ";
            strSqlList += "FROM [IN].Eop AS EOP LEFT OUTER JOIN [IN].StoreLocation AS Sto ON (Sto.LocationCode = EOP.StoreId) ";
            strSqlList += "WHERE EOP.EndDate = '" + endDate + "' AND Sto.EOP = 1 ";
            SqlCommand cmd = new SqlCommand(strSqlList, cnn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dtList = new DataTable();
            da.Fill(dtList);
            dsPeriod.Tables.Add(dtList);
            Session["dsPeriod"] = dsPeriod;
        }

        protected void SetStatusTable()
        {
            //int numberOfRecords = dtFoo.AsEnumerable().Where(x => x["IsActive"].ToString() == "Y").ToList().Count;
            //string PC = string.Format("Status like '%{0}%' OR Status like '%{1}%'", "Printed", "Committed");
            string UnP = string.Format("Status NOT Like '%{0}%' AND Status NOT Like '%{1}%'", "Printed", "Committed");
            int numUNP = dsPeriod.Tables[1].Select(UnP).Length;
            int numPrinted = dsPeriod.Tables[1].Select("Status = 'Printed'").Length;
            int numCom = dsPeriod.Tables[1].Select("Status = 'Committed'").Length;
            int numTotal = dsPeriod.Tables[1].Rows.Count;
            lbl_CountUNP.Text = numUNP.ToString();
            lbl_CountP.Text = numPrinted.ToString();
            lbl_CountCom.Text = numCom.ToString();
            lbl_CountTotal.Text = "/ " + numTotal.ToString();
        }

        protected void btn_OK_Click(object sender, EventArgs e)
        {
            if (dsPeriod.Tables[period.TableName].Rows.Count > 0)
            {
                var drPeriod = dsPeriod.Tables[period.TableName].Rows[0];
                var result = period.CheckEndDate(DateTime.Parse(drPeriod["EndDate"].ToString()), LoginInfo.ConnStr);
                if (result)
                {
                    period.PeriodEnd(DateTime.Parse(drPeriod["StartDate"].ToString()),
                        DateTime.Parse(drPeriod["EndDate"].ToString()),
                        LoginInfo.LoginName, LoginInfo.ConnStr);

                    // Added on: 22/09/2017, By: Fon
                    ClassLogTool pctool = new ClassLogTool();
                    string returnDef = pctool.DefragmentActionLog(3);
                    pctool.SaveActionLog("EOP", string.Empty, "Closed Period: " + lbl_EndDate.Text);
                    // End Added.

                    // Display Sucessful Message
                    Page_Retrieve();
                }
                else
                {
                    pop_Warning.ShowOnPageLoad = true;
                }
            }
        }

        protected void btn_Warning_Click(object sender, EventArgs e)
        {
            pop_Warning.ShowOnPageLoad = false;
        }

        protected void gvStoreList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvStoreList.PageIndex = e.NewPageIndex;
            gvStoreList.DataSource = dsPeriod.Tables[1];
            gvStoreList.DataBind();
        }

        protected void lbtnUNP_Click(object sender, EventArgs e)
        {
            FilterClick("UNP");
        }

        protected void ltbnP_Click(object sender, EventArgs e)
        {
            FilterClick("P");
        }

        protected void lbtnCom_Click(object sender, EventArgs e)
        {
            FilterClick("C");
        }

        private void FilterClick(string type)
        {
            string filter = string.Empty;
            switch (type)
            {
                case "UNP":
                    filter = string.Format("Status NOT Like '%{0}%' AND Status NOT Like '%{1}%'", "Printed", "Committed");
                    break;

                case "P":
                    filter = "Status = 'Printed'";
                    break;

                case "C":
                    filter = "Status = 'Committed'";
                    break;

            }

            dsPeriod.Tables[1].DefaultView.RowFilter = filter;
            gvStoreList.DataSource = dsPeriod.Tables[1];
            gvStoreList.DataBind();
        }
    }
}