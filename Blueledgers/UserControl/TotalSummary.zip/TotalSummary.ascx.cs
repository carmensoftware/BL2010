﻿using System;
using System.Collections.Generic;

using BlueLedger.PL.BaseClass;
using System.Web.UI.WebControls;
using System.Web.UI;


namespace BlueLedger.PL.UserControls
{
    public partial class TotalSummary : BaseUserControl
    {
        #region --Attributes--

        private readonly BasePage basePage = new BasePage();

        // Private
        private decimal _currNetAmt;
        private decimal _currTaxAmt;
        private decimal _currTotalAmt;
        private decimal _netAmt;
        private decimal _taxAmt;
        private decimal _totalAmt;


        // Public
        public decimal CurrencyNetAmount { get { return _currNetAmt; } set { _currNetAmt = value; } }
        public decimal CurrencyTaxAmount { get { return _currTaxAmt; } set { _currTaxAmt = value; } }
        public decimal CurrencyTotalAmount { get { return _currTotalAmt; } set { _currTotalAmt = value; } }
        public decimal NetAmount { get { return _netAmt; } set { _netAmt = value; } }
        public decimal TaxAmount { get { return _taxAmt; } set { _taxAmt = value; } }
        public decimal TotalAmount { get { return _totalAmt; } set { _totalAmt = value; } }

        #endregion

        public override void DataBind()
        {
            base.DataBind();

            lb_CurrNetAmt.Text = basePage.FormatAmt(_currNetAmt);
            lb_CurrTaxAmt.Text = basePage.FormatAmt(_currTaxAmt);
            lb_CurrTotalAmt.Text = basePage.FormatAmt(_currTotalAmt);

            lb_NetAmt.Text = basePage.FormatAmt(_netAmt);
            lb_TaxAmt.Text = basePage.FormatAmt(_taxAmt);
            lb_TotalAmt.Text = basePage.FormatAmt(_totalAmt);
        }
    }
}

