﻿using System;
using System.Data.SqlClient;
using FastReport;
using BlueLedger.PL.BaseClass;

public partial class RPT_PrintForm : BasePage
{
    string id = string.Empty;

    protected override void Page_Load(object sender, EventArgs e)
    {
        id = Request.QueryString["ID"];
        string reportName = Request.QueryString["Report"];
        string rptID = string.Empty;
        if (reportName == "PurchaseRequestForm")
            rptID = "9001";
        else if (reportName == "PurchaseOrderForm")
            rptID = "9002";
        else
            reportName = reportName + ".frx";


        if (rptID != string.Empty)
        {
            string sql = string.Format("SELECT TOP(1) RptFileName FROM RPT.Report2 WHERE RptID = '{0}'", rptID);

            SqlConnection conn = new SqlConnection(LoginInfo.ConnStr);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Connection.Open();
            object rptFileName = cmd.ExecuteScalar();
            conn.Close();

            if (rptFileName == null)
                reportName = reportName + ".frx";
            else
                reportName = rptFileName.ToString();
        }

        WebReport1.ReportFile = @"~\App_Files\Reports\" + reportName;

        //ReportPage page = WebReport1.Report.FindObject("Page1") as ReportPage;
        //ReportPage page = WebReport1.Report.Pages[0] as ReportPage;

        //WebReport1.Width = (int)Math.Round(page.WidthInPixels);
        //WebReport1.Height = (int)Math.Round(page.HeightInPixels);

        //WebReport1.Width = 780;
        //WebReport1.Height = 740;
        WebReport1.Width = 1200;
        WebReport1.Height = 740;


    }
    protected void WebReport1_StartReport(object sender, EventArgs e)
    {
        WebReport1.Report.SetParameterValue("ID", id);

        for (var i = 0; i < WebReport1.Report.Dictionary.Connections.Count; i++)
            WebReport1.Report.Dictionary.Connections[0].ConnectionString = LoginInfo.ConnStr;
    }
}