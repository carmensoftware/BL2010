﻿using System;
using System.Collections;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using BlueLedger.PL.BaseClass;
using DevExpress.Web.ASPxClasses;
using DevExpress.Web.ASPxEditors;
using System.Drawing;
using System.Data.SqlClient;


namespace BlueLedger.PL.Option.Inventory
{
    public partial class ProdEdit2 : BasePage
    {
        private readonly Blue.BL.dbo.Bu bu = new Blue.BL.dbo.Bu();
        private readonly UnitLookup _unitLookup = new UnitLookup();
        private readonly Blue.BL.Option.Inventory.ApprLv apprLv = new Blue.BL.Option.Inventory.ApprLv();
        private readonly Blue.BL.Option.Inventory.Product product = new Blue.BL.Option.Inventory.Product();
        private readonly Blue.BL.Option.Inventory.ProdLoc prodLoc = new Blue.BL.Option.Inventory.ProdLoc();
        private readonly Blue.BL.Option.Inventory.ProdLocHQ prodLocHQ = new Blue.BL.Option.Inventory.ProdLocHQ();
        private readonly Blue.BL.Option.Inventory.ProdCat prodCat = new Blue.BL.Option.Inventory.ProdCat();

        private readonly Blue.BL.Option.Inventory.Unit unit = new Blue.BL.Option.Inventory.Unit();
        private readonly Blue.BL.IN.ProdUnit prodUnit = new Blue.BL.IN.ProdUnit();
        private readonly Blue.BL.ADMIN.TransLog _transLog = new Blue.BL.ADMIN.TransLog();
        private Blue.BL.GL.Account.Account account = new Blue.BL.GL.Account.Account();
        private Blue.BL.APP.Config config = new Blue.BL.APP.Config();

        private DataSet dsProductEdit = new DataSet();
        private DataSet dsUnit = new DataSet();
        private DataTable dtItemGroup = new DataTable();
        private string msgError = string.Empty;
        private string _action = string.Empty;
        private string UnitMode
        {
            get { return ViewState["UnitMode"].ToString(); }
            set { ViewState["UnitMode"] = value; }
        }

        private string statusActiveText = "Active";
        private string statusInactiveText = "Inactive";

        /// <summary>
        ///     Gets and display season data when page load.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void Page_Load(object sender, EventArgs e)
        {
            //hf_ConnStr.Value = LoginInfo.ConnStr;
            if (Request.Params["BuCode"] != null)
            {
                hf_ConnStr.Value = bu.GetConnectionString(Request.Params["BuCode"]);
            }
            else
            {
                hf_ConnStr.Value = LoginInfo.ConnStr;
            }

            base.Page_Load(sender, e);

            if (!IsPostBack)
            {
                Page_Retrieve();
                Page_Setting();
            }
            else
            {
                dsProductEdit = (DataSet)Session["dsProductEdit"];
                dsUnit = (DataSet)Session["dsUnit"];
            }

            ASPxWebControl.RegisterBaseScript(Page);
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            cmb_InventoryUnit.ValueField = "UnitCode";
            cmb_InventoryUnit.TextField = "UnitCode";
            cmb_InventoryUnit.TextFormatString = "{0}";
            cmb_InventoryUnit.DataSource = unit.GetUnitLookup(bu.GetConnectionString(Request.Params["BuCode"]));
            cmb_InventoryUnit.DataBind();

            ddl_SubCategory.DataSource = null;
            ddl_SubCategory.DataBind();

            ddl_ItemGroup.DataSource = null;
            ddl_ItemGroup.DataBind();
        }

        /// <summary>
        ///     Gets season data.
        /// </summary>
        private void Page_Retrieve()
        {
            if (Request.Params["MODE"].ToUpper() == "EDIT")
            {
                if (dsProductEdit != null)
                {
                    dsProductEdit.Clear();
                }

                // Get list by productcode.
                product.GetList(dsProductEdit, Request.Params["ID"], hf_ConnStr.Value);

                var getProdUnit = prodUnit.GetListAll(dsProductEdit, Request.Params["ID"], hf_ConnStr.Value);

                var getProdUnitO = prodUnit.GetListByUnitType(dsProductEdit, Request.Params["ID"], "OrderUnit", "O",
                    hf_ConnStr.Value);
                var getProdUnitR = prodUnit.GetListByUnitType(dsProductEdit, Request.Params["ID"], "RecipeUnit", "R",
                    hf_ConnStr.Value);

                if (getProdUnit)
                {
                    //DataView dvTable  = dsProductEdit.Tables[prodUnit.TableName].DefaultView;
                    //dvTable.RowFilter = " [UnitType] = 'O'";

                    if (dsProductEdit != null)
                    {
                        grd_OrderUnit1.DataSource = dsProductEdit.Tables["OrderUnit"]; //dvTable;
                        grd_OrderUnit1.DataBind();

                        //dvTable           = dsProductEdit.Tables[prodUnit.TableName].DefaultView;
                        //dvTable.RowFilter = " [UnitType] = 'R'";

                        grd_RecipeUnit.DataSource = dsProductEdit.Tables["RecipeUnit"]; //dvTable;
                    }
                    grd_RecipeUnit.DataBind();
                }
            }
            else
            {
                //Get Schema 
                prodUnit.GetSchema(dsProductEdit, hf_ConnStr.Value);
                prodUnit.GetSchema(dsProductEdit, "OrderUnit", hf_ConnStr.Value);
                prodUnit.GetSchema(dsProductEdit, "RecipeUnit", hf_ConnStr.Value);
            }

            //dsUnit.Clear();

            //bool getUnit = unit.GetList(dsUnit, hf_ConnStr.Value);

            //if (getUnit)
            //{
            //    // Assign Primarykey                
            //    dsUnit.Tables[unit.TableName].PrimaryKey = this.GetPK();

            //    Session["dsUnit"] = dsUnit;
            //}
            //else
            //{
            //    // Display Error Message
            //    return;
            //}

            Session["dsProductEdit"] = dsProductEdit;
        }

        /// <summary>
        ///     Display season data.
        /// </summary>
        private void Page_Setting()
        {
            // Added on: 02/04/2018, By: Fon, For: Product Mapp
            lbl_Header_HQSKU.Visible = false;
            ddl_HQSKU.Visible = false;

            if (IsBUHQActive() && !LoginInfo.BuInfo.IsHQ)
            {
                lbl_Header_HQSKU.Visible = true;
                ddl_HQSKU.Visible = true;

                //ddl_HQSKU.DataSource = product.GetActiveList(bu.GetHQConnStr(LoginInfo.BuInfo.BuGrpCode));
                //ddl_HQSKU.DataTextField = "ProductDesc1";
                //ddl_HQSKU.DataValueField = "ProductCode";
                //ddl_HQSKU.DataBind();

                ddl_HQSKU.DataSource = product.GetActiveList(bu.GetHQConnStr(LoginInfo.BuInfo.BuGrpCode));
                ddl_HQSKU.DataBind();
                ddl_HQSKU.Items.Insert(0, new ListEditItem(string.Empty, string.Empty));
            }
            // End Added.



            //chk_Status.Checked = Convert.ToBoolean(dsProductEdit.Tables[product.TableName].Rows[0]["IsActive"]);

            //btn_Status.Text = chk_Status.Checked == true ? statusInactiveText : statusActiveText;
            //btn_Status.ForeColor = chk_Status.Checked == true ? Color.Red : Color.Blue;

            //lbl_Status.Text = chk_Status.Checked == true ? statusActiveText : statusInactiveText;
            //lbl_Status.ForeColor = chk_Status.Checked == true ? Color.Blue : Color.Red;



            #region Edit Mode
            if (Request.Params["MODE"].ToUpper() == "EDIT")
            {
                txt_Code.Text = dsProductEdit.Tables[product.TableName].Rows[0]["ProductCode"].ToString();

                txt_Description1.Text = dsProductEdit.Tables[product.TableName].Rows[0]["ProductDesc1"].ToString();
                txt_Descritpion2.Text = dsProductEdit.Tables[product.TableName].Rows[0]["ProductDesc2"].ToString();

                bool isActive = Convert.ToBoolean(dsProductEdit.Tables[product.TableName].Rows[0]["IsActive"]);
                SetActiveProduct(isActive);


                // Product category binding for level 3.
                var dtItemGroup = product.GetItemGroupListLookup(hf_ConnStr.Value);
                ddl_ItemGroup.DataSource = dtItemGroup;
                ddl_ItemGroup.DataTextField = "CategoryName";
                ddl_ItemGroup.DataValueField = "CategoryCode";
                ddl_ItemGroup.DataBind();
                ddl_ItemGroup.SelectedValue = dsProductEdit.Tables[product.TableName].Rows[0]["ProductCate"].ToString();

                // Product category binding for level 2.
                var dtProdSubCat = product.GetSubCategoryListLookup(hf_ConnStr.Value);
                ddl_SubCategory.DataSource = dtProdSubCat;
                ddl_SubCategory.DataTextField = "CategoryName";
                ddl_SubCategory.DataValueField = "CategoryCode";
                ddl_SubCategory.DataBind();
                ddl_SubCategory.SelectedValue =
                    product.GetParentNoByCategoryCode(
                        dsProductEdit.Tables[product.TableName].Rows[0]["ProductCate"].ToString(), hf_ConnStr.Value);

                // Product category binding for level 1.
                var dtProdCat = product.GetCategoryListLookup(hf_ConnStr.Value);
                ddl_Category.DataSource = dtProdCat;
                ddl_Category.DataTextField = "CategoryName";
                ddl_Category.DataValueField = "CategoryCode";
                ddl_Category.DataBind();
                ddl_Category.SelectedValue = product.GetParentNoByCategoryCode(ddl_SubCategory.SelectedItem.Value,
                    hf_ConnStr.Value);

                // BarCOde
                txt_BarCode.Text = dsProductEdit.Tables[product.TableName].Rows[0]["BarCode"].ToString();
                txt_OrderUnit.Text = dsProductEdit.Tables[product.TableName].Rows[0]["OrderUnit"].ToString();

                txt_OrderUnit.Text = dsProductEdit.Tables[product.TableName].Rows[0]["OrderUnit"].ToString().Equals("")
                    ? string.Empty
                    : (dsProductEdit.Tables[product.TableName].Rows[0]["OrderUnit"].ToString());

                // OrderConverseRate
                txt_InvenConvOrder.Text = string.Format(DefaultQtyFmt, dsProductEdit.Tables[product.TableName].Rows[0]["InventoryConvOrder"]);

                cmb_InventoryUnit.Value = dsProductEdit.Tables[product.TableName].Rows[0]["InventoryUnit"].ToString();

                if (dsProductEdit.Tables[product.TableName].Rows[0]["InventoryUnit"].ToString().Equals(""))
                {
                    cmb_InventoryUnit.Enabled = true;
                    cmb_InventoryUnit.Value = System.DBNull.Value;
                }
                else
                {
                    cmb_InventoryUnit.Enabled = false;
                    cmb_InventoryUnit.Value =
                        (dsProductEdit.Tables[product.TableName].Rows[0]["InventoryUnit"].ToString());
                }

                txt_RecipeUnit.Text = dsProductEdit.Tables[product.TableName].Rows[0]["RecipeUnit"].ToString();

                txt_RecipeUnit.Text = dsProductEdit.Tables[product.TableName].Rows[0]["RecipeUnit"].ToString()
                    .Equals("")
                    ? string.Empty
                    : (dsProductEdit.Tables[product.TableName].Rows[0]["RecipeUnit"].ToString());

                ddl_TAXType.SelectedValue = dsProductEdit.Tables[product.TableName].Rows[0]["TAXType"].ToString();

                txt_RecipeConverseRate.Text =
                    dsProductEdit.Tables[product.TableName].Rows[0]["RecipeConvInvent"].ToString();
                txt_TaxRate.Text = dsProductEdit.Tables[product.TableName].Rows[0]["TaxRate"].ToString();

                txt_StandardCost.Text = dsProductEdit.Tables[product.TableName].Rows[0]["StandardCost"].ToString();
                //txt_LastCost.Text             = dsProductEdit.Tables[product.TableName].Rows[0]["LastCost"].ToString();

                // Get Last Price.
                var dsLastPrice = new DataSet();
                var getLastPrice = product.GetLastPrice(dsLastPrice,
                    dsProductEdit.Tables[product.TableName].Rows[0]["ProductCode"].ToString(), hf_ConnStr.Value);

                if (getLastPrice)
                {
                    if (dsLastPrice.Tables[product.TableName].Rows.Count > 0)
                    {
                        var drLastPrice = dsLastPrice.Tables[product.TableName].Rows[0];

                        txt_LastCost.Text = String.Format(DefaultAmtFmt, drLastPrice["LastPrice"]);
                    }
                }

                txt_QuantityDeviation.Text =
                    dsProductEdit.Tables[product.TableName].Rows[0]["QuantityDeviation"].ToString();
                txt_PriceDeviation.Text = dsProductEdit.Tables[product.TableName].Rows[0]["PriceDeviation"].ToString();

                chk_ReqHQAppr.Checked =
                    (Convert.ToBoolean(dsProductEdit.Tables[product.TableName].Rows[0]["ReqHQAppr"]));

                txt_TaxAccCode.Text = dsProductEdit.Tables[product.TableName].Rows[0]["TaxAccCode"].ToString();

                chk_IsRecipe.Checked = (dsProductEdit.Tables[product.TableName].Rows[0]["IsRecipe"].ToString() !=
                                        string.Empty &&
                                        Convert.ToBoolean(dsProductEdit.Tables[product.TableName].Rows[0]["IsRecipe"]));
                chk_SaleItem.Checked = Convert.ToBoolean(dsProductEdit.Tables[product.TableName].Rows[0]["SaleItem"]);

                //txt_ApprovalLevel.Text      = dsProductEdit.Tables[product.TableName].Rows[0]["ApprovalLevel"].ToString();
                //ddl_ApprovalLevel.Value = dsProductEdit.Tables[product.TableName].Rows[0]["ApprovalLevel"] + " : " + apprLv.GetName(dsProductEdit.Tables[product.TableName].Rows[0]["ApprovalLevel"].ToString(), hf_ConnStr.Value);
                var apprLvCode = dsProductEdit.Tables[product.TableName].Rows[0]["ApprovalLevel"];
                if (!string.IsNullOrEmpty(apprLvCode.ToString()))
                {
                    ddl_ApprovalLevel.Value = Convert.ToInt32(apprLvCode.ToString());
                }

                // Added on: 02/04/2018, By: Fon
                if (ddl_HQSKU.Visible)
                    ddl_HQSKU.Value = string.Format("{0}", dsProductEdit.Tables[product.TableName].Rows[0]["Addfield10"]);
                // End Added.
            }
            #endregion
            #region Create Mode
            else
            {
                // Enable dropdown controls
                EnableControls();

                // Default
                chk_Status.Checked = true;

                // Product category binding for level 1.
                var dtProdCat = product.GetCategoryListLookup(hf_ConnStr.Value);

                ddl_Category.DataSource = dtProdCat;
                ddl_Category.DataTextField = "CategoryName";
                ddl_Category.DataValueField = "CategoryCode";
                ddl_Category.DataBind();

                // Product category binding for level 2.
                //DataTable dtProdSubCat             = product.GetSubCategoryListLookup(hf_ConnStr.Value);
                //ddl_SubCategory.DataSource         = dtProdSubCat;
                //ddl_SubCategory.DataTextField      = "CategoryName";
                //ddl_SubCategory.DataValueField     = "CategoryCode";
                //ddl_SubCategory.DataBind();

                // Product category binding for level 3.
                //DataTable dtItemGroup             = product.GetItemGroupListLookup(hf_ConnStr.Value);
                //ddl_ItemGroup.DataSource          = dtItemGroup;
                //ddl_ItemGroup.DataTextField       = "CategoryName";
                //ddl_ItemGroup.DataValueField      = "CategoryCode";
                //ddl_ItemGroup.DataBind();

                // Show Prod Unit
                //grd_ProdUnit.DataBind();

                grd_OrderUnit1.DataBind();
                grd_RecipeUnit.DataBind();

                SetActiveProduct(true);
            }
            #endregion

            //grd_Unit.DataSource = dsUnit.Tables[unit.TableName];
            //grd_Unit.DataBind();

            //if (!(chk_IsRecipe.Checked))
            //{
            //    cmb_RecipeUnit.Enabled          = false;
            //    txt_RecipeConverseRate.Enabled  = false;
            //}

            //this.EnableRecipeControls();

        }

        /// <summary>
        /// </summary>
        private void EnableControls()
        {
            ddl_Category.Enabled = true;
            ddl_SubCategory.Enabled = true;
            ddl_ItemGroup.Enabled = true;
        }

        /// <summary>
        ///     Recipe Controls enable
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EnableRecipeControls()
        {
            if (chk_IsRecipe.Checked)
            {
                //txt_RecipeUnit.Enabled        = true;
                txt_RecipeConverseRate.Enabled = true;
                //req_RecipeUnit.Enabled        = true;
                //req_RecipeConverseRate.Enabled  = true;
                //reg_RecipeConverseRate.Enabled  = true;
            }
            else
            {
                //cmb_RecipeUnit.Enabled         = false;
                txt_RecipeConverseRate.Enabled = false;
                //cmb_RecipeUnit.Value           = string.Empty;
                txt_RecipeConverseRate.Text = string.Empty;
                //req_RecipeUnit.Enabled         = false;
                //req_RecipeConverseRate.Enabled = false;
                //reg_RecipeConverseRate.Enabled = false;
            }

            if (ddl_TAXType.SelectedItem.Value.ToUpper() == "N")
            {
                txt_TaxRate.Text = Convert.ToInt32("0").ToString();
                //reg_TaxRate.Enabled = false;
            }
            else if (ddl_TAXType.SelectedItem.Value.ToUpper() == "I")
            {
                //txt_TaxRate.Text = string.Empty;
                //reg_TaxRate.Enabled = true;
            }
            else if (ddl_TAXType.SelectedItem.Value.ToUpper() == "A")
            {
                //txt_TaxRate.Text = string.Empty;
                //reg_TaxRate.Enabled = true;
            }
        }

        protected void ddl_TaxAccCode_SelectedIndexChanged(object sender, EventArgs e)
        {
        }


        /////////////////////////////////////////////////////////////////////////

        protected void cmb_InventoryUnit_OnItemsRequestedByFilterCondition(object source, ListEditItemsRequestedByFilterConditionEventArgs e)
        {
            var comboBox = (ASPxComboBox)source;
            _unitLookup.ItemsRequestedByFilterCondition(ref comboBox, SqlDataSource1, LoginInfo.ConnStr, e);
        }

        protected void cmb_InventoryUnit_OnItemRequestedByValue(object source, ListEditItemRequestedByValueEventArgs e)
        {
            var comboBox = (ASPxComboBox)source;
            _unitLookup.ItemRequestedByValue(ref comboBox, SqlDataSource1, LoginInfo.ConnStr, e);
        }

        /////////////////////////////////////////////////////////////////////////

        //protected void cmb_InventoryUnit_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //}

        protected void ddl_Category_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            // Product category binding for level 2.
            var dtProdSubCat = product.GetSubCategoryListLookup(hf_ConnStr.Value);
            dtProdSubCat.DefaultView.RowFilter = "ParentNo = '" + ddl_Category.SelectedItem.Value + "' ";
            var dvProdSubCat = dtProdSubCat.DefaultView;
            ddl_SubCategory.DataSource = dvProdSubCat;
            ddl_SubCategory.DataTextField = "CategoryName";
            ddl_SubCategory.DataValueField = "CategoryCode";
            ddl_SubCategory.DataBind();

            // Product category binding for level 3.
            dtItemGroup = product.GetItemGroupListLookupByParentNo(ddl_SubCategory.SelectedItem.Value, hf_ConnStr.Value);

            ddl_ItemGroup.DataSource = dtItemGroup;
            ddl_ItemGroup.DataTextField = "CategoryName";
            ddl_ItemGroup.DataValueField = "CategoryCode";
            ddl_ItemGroup.DataBind();

            txt_Code.Text = string.Empty;
            ddl_ItemGroup.SelectedValue = string.Empty;
        }

        /// <summary>
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddl_SubCategory_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            // Product category binding for level 3.
            dtItemGroup = product.GetItemGroupListLookupByParentNo(ddl_SubCategory.SelectedItem.Value, hf_ConnStr.Value);

            ddl_ItemGroup.DataSource = dtItemGroup;
            ddl_ItemGroup.DataTextField = "CategoryName";
            ddl_ItemGroup.DataValueField = "CategoryCode";
            ddl_ItemGroup.DataBind();

            txt_Code.Text = string.Empty;
        }

        /// <summary>
        ///     Itemgroup selected change
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddl_ItemGroup_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            txt_Code.Text = ddl_ItemGroup.SelectedValue.ToString() + "xxxx";

            string taxAccCode1 = string.Empty;
            string taxAccCode2 = string.Empty;
            string taxAccCode3 = string.Empty;

            string priceDeviation1 = string.Empty;
            string priceDeviation2 = string.Empty;
            string priceDeviation3 = string.Empty;

            string qtyDeviation1 = string.Empty;
            string qtyDeviation2 = string.Empty;
            string qtyDeviation3 = string.Empty;

            // Category (Level=1)
            string sql1 = string.Format("SELECT TaxAccCode, PriceDeviation, QuantityDeviation FROM [IN].ProductCategory WHERE LevelNo=1 AND CategoryCode = '{0}'", ddl_Category.SelectedItem.Value);
            DataTable dt1 = prodCat.DbExecuteQuery(sql1, null, hf_ConnStr.Value);
            if (dt1 != null)
            {
                DataRow dr = dt1.Rows[0];
                taxAccCode1 = dr["TaxAccCode"].ToString();
                priceDeviation1 = dr["PriceDeviation"].ToString();
                qtyDeviation1 = dr["QuantityDeviation"].ToString();
            }

            // Sub-Category (Level=2)
            string sql2 = string.Format("SELECT TaxAccCode, PriceDeviation, QuantityDeviation FROM [IN].ProductCategory WHERE LevelNo=2 AND CategoryCode = '{0}'", ddl_SubCategory.SelectedItem.Value);
            DataTable dt2 = prodCat.DbExecuteQuery(sql2, null, hf_ConnStr.Value);
            if (dt2 != null)
            {
                DataRow dr = dt2.Rows[0];
                taxAccCode2 = dr["TaxAccCode"].ToString();
                priceDeviation2 = dr["PriceDeviation"].ToString();
                qtyDeviation2 = dr["QuantityDeviation"].ToString();
            }



            // Item-Group (Level=3)
            string sql3 = string.Format("SELECT TaxAccCode, PriceDeviation, QuantityDeviation FROM [IN].ProductCategory WHERE LevelNo=3 AND CategoryCode = '{0}'", ddl_ItemGroup.SelectedItem.Value);
            DataTable dt3 = prodCat.DbExecuteQuery(sql3, null, hf_ConnStr.Value);
            if (dt3 != null)
            {
                DataRow dr = dt3.Rows[0];
                taxAccCode3 = dr["TaxAccCode"].ToString();
                priceDeviation3 = dr["PriceDeviation"].ToString();
                qtyDeviation3 = dr["QuantityDeviation"].ToString();
            }


            // TaxAccCode (txt_Code)
            if (!string.IsNullOrEmpty(taxAccCode3))
            {
                txt_TaxAccCode.Text = taxAccCode3;
            }
            else if (!string.IsNullOrEmpty(taxAccCode2))
            {
                txt_TaxAccCode.Text = taxAccCode2;
            }
            else if (!string.IsNullOrEmpty(taxAccCode1))
            {
                txt_TaxAccCode.Text = taxAccCode1;
            }
            else
                txt_TaxAccCode.Text = string.Empty;


            // PriceDeviation (txt_PriceDeviation)
            if (!string.IsNullOrEmpty(priceDeviation3))
            {
                txt_PriceDeviation.Text = priceDeviation3;
            }
            else if (!string.IsNullOrEmpty(priceDeviation2))
            {
                txt_PriceDeviation.Text = priceDeviation2;
            }
            else if (!string.IsNullOrEmpty(priceDeviation1))
            {
                txt_PriceDeviation.Text = priceDeviation1;
            }
            else
                txt_PriceDeviation.Text = "0.00";

            // QuantityDeviation (txt_QuantityDeviation)
            if (!string.IsNullOrEmpty(qtyDeviation3))
            {
                txt_QuantityDeviation.Text = qtyDeviation3;
            }
            else if (!string.IsNullOrEmpty(qtyDeviation2))
            {
                txt_QuantityDeviation.Text = qtyDeviation2;
            }
            else if (!string.IsNullOrEmpty(qtyDeviation1))
            {
                txt_QuantityDeviation.Text = qtyDeviation1;
            }
            else
                txt_QuantityDeviation.Text = "0.00";
            //txt_Code.Text = string.Empty;
            //txt_PriceDeviation.Text = "0.00";
            //txt_QuantityDeviation.Text = "0.00";

            //txt_ApprovalLevel.Text = (prodCat.ProdCat_GeApprovalLevelByCategoryCode(Convert.ToInt32(ddl_ItemGroup.SelectedItem.Value.ToString()), hf_ConnStr.Value).ToString());

            //var ApprovalLevel = prodCat.ProdCat_GeApprovalLevelByCategoryCode((ddl_ItemGroup.SelectedItem.Value),
            //    hf_ConnStr.Value);
            //var ApprovalName = apprLv.GetName(ApprovalLevel.ToString(), hf_ConnStr.Value);
            //ddl_ApprovalLevel.Value = (ApprovalLevel + " : " + ApprovalName);

            //try
            //{
            //   txt_TaxAccCode.Text = prodCat.ProdCat_GetTaxAccCodeByCategoryCode(ddl_ItemGroup.SelectedItem.Value, hf_ConnStr.Value);
            //}
            //catch
            //{
            //    txt_TaxAccCode.Text = string.Empty;
            //}

        }

        /// <summary>
        ///     Check Recipe item or not
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void chk_IsRecipe_OnCheckedChanged(object sender, EventArgs e)
        {
            //if (chk_IsRecipe.Checked)
            //{
            //    cmb_RecipeUnit.Enabled = true;
            //    txt_RecipeConverseRate.Enabled = true;
            //    req_RecipeUnit.Enabled = true;
            //    req_RecipeConverseRate.Enabled = true;
            //    reg_RecipeConverseRate.Enabled = true;

            //}
            //else
            //{
            //    cmb_RecipeUnit.Enabled = false;
            //    txt_RecipeConverseRate.Enabled = false;
            //    cmb_RecipeUnit.Value = string.Empty;
            //    txt_RecipeConverseRate.Text    = string.Empty;
            //    req_RecipeUnit.Enabled         = false;
            //    req_RecipeConverseRate.Enabled = false;
            //    reg_RecipeConverseRate.Enabled = false;

            //}
        }

        /// <summary>
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddl_TAXType_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddl_TAXType.SelectedItem.Value.ToUpper() == "N")
            {
                txt_TaxRate.Text = Convert.ToInt32("0").ToString();
                //reg_TaxRate.Enabled = false;
            }
            else if (ddl_TAXType.SelectedItem.Value.ToUpper() == "I")
            {
                txt_TaxRate.Text = string.Empty;
                //reg_TaxRate.Enabled = true;
            }
            else if (ddl_TAXType.SelectedItem.Value.ToUpper() == "A")
            {
                txt_TaxRate.Text = string.Empty;
                //reg_TaxRate.Enabled = true;
            }
        }

        /// <summary>
        /// </summary>
        /// <param name="source"></param>
        /// <param name="e"></param>
        protected void menu_CmdBar_ItemClick(object source, DevExpress.Web.ASPxMenu.MenuItemEventArgs e)
        {
            switch (e.Item.Name.ToUpper())
            {
                case "SAVE":
                    Page.Validate();

                    if (Page.IsValid)
                    {
                        PrepareProdUnit();

                        bool hasChangeDescription = false;

                        #region Edit Mode
                        if (Request.Params["MODE"].ToUpper() == "EDIT")
                        {
                            var drProductEdit = dsProductEdit.Tables[product.TableName].Rows[0];

                            hasChangeDescription = drProductEdit["ProductDesc1"].ToString() != txt_Description1.Text || drProductEdit["ProductDesc2"].ToString() != txt_Descritpion2.Text;

                            drProductEdit["ProductCode"] = txt_Code.Text.Trim();
                            drProductEdit["ProductDesc1"] = txt_Description1.Text;
                            drProductEdit["ProductDesc2"] = txt_Descritpion2.Text;
                            drProductEdit["ProductCate"] = ddl_ItemGroup.SelectedItem.Value;
                            drProductEdit["BarCode"] = txt_BarCode.Text;

                            if (cmb_InventoryUnit.SelectedIndex >= 0)
                            {
                                drProductEdit["InventoryUnit"] = (cmb_InventoryUnit.SelectedItem.Value.ToString());
                            }
                            else
                            {
                                drProductEdit["InventoryUnit"] = System.DBNull.Value;
                            }

                            if (txt_OrderUnit.Text != string.Empty)
                            {
                                drProductEdit["OrderUnit"] = (txt_OrderUnit.Text);
                            }
                            else
                            {
                                drProductEdit["OrderUnit"] = (cmb_InventoryUnit.SelectedItem.Value.ToString());
                            }

                            if (txt_RecipeUnit.Text != string.Empty)
                            {
                                drProductEdit["RecipeUnit"] = txt_RecipeUnit.Text;
                            }
                            else
                            {
                                drProductEdit["RecipeUnit"] = System.DBNull.Value;
                            }

                            if (txt_InvenConvOrder.Text != string.Empty)
                            {
                                drProductEdit["InventoryConvOrder"] = Convert.ToDecimal(txt_InvenConvOrder.Text);
                            }
                            else
                            {
                                drProductEdit["InventoryConvOrder"] = 1.00;
                            }

                            if (txt_RecipeConverseRate.Text != string.Empty)
                            {
                                drProductEdit["RecipeConvInvent"] = Convert.ToDecimal(txt_RecipeConverseRate.Text);
                            }
                            else
                            {
                                drProductEdit["RecipeConvInvent"] = 0.00;
                            }

                            if (ddl_TAXType.SelectedItem.Value != string.Empty)
                            {
                                drProductEdit["TaxType"] = ddl_TAXType.SelectedItem.Value;
                            }

                            //if (txt_TaxRate.Text != string.Empty)
                            //{
                            //    drProductEdit["TaxRate"] = Convert.ToDecimal(txt_TaxRate.Text.ToString());
                            //}
                            //else
                            //{
                            //    drProductEdit["TaxRate"] = 0;
                            //}

                            if (!string.IsNullOrEmpty(txt_TaxRate.Text) && ddl_TAXType.SelectedItem.Value == "N")
                            {
                                drProductEdit["TaxRate"] = 0;
                            }
                            else if (!string.IsNullOrEmpty(txt_TaxRate.Text) && ddl_TAXType.SelectedItem.Value != "N")
                            {
                                drProductEdit["TaxRate"] = Convert.ToDecimal(txt_TaxRate.Text);
                            }
                            else
                            {
                                pop_AlertTaxRate.ShowOnPageLoad = true;
                                return;
                            }

                            if (txt_StandardCost.Text != string.Empty)
                            {
                                drProductEdit["StandardCost"] = Convert.ToDecimal(txt_StandardCost.Text);
                            }
                            else
                            {
                                drProductEdit["StandardCost"] = 0;
                            }

                            if (txt_LastCost.Text != string.Empty)
                            {
                                drProductEdit["LastCost"] = Convert.ToDecimal(txt_LastCost.Text);
                            }
                            else
                            {
                                drProductEdit["LastCost"] = 0;
                            }

                            if (txt_QuantityDeviation.Text != string.Empty)
                            {
                                drProductEdit["QuantityDeviation"] = Convert.ToDecimal(txt_QuantityDeviation.Text);
                            }
                            else
                            {
                                drProductEdit["QuantityDeviation"] = 0;
                            }

                            if (txt_PriceDeviation.Text != string.Empty)
                            {
                                drProductEdit["PriceDeviation"] = Convert.ToDecimal(txt_PriceDeviation.Text);
                            }
                            else
                            {
                                drProductEdit["PriceDeviation"] = 0;
                            }

                            if (chk_ReqHQAppr.Checked)
                            {
                                drProductEdit["ReqHQAppr"] = true;
                            }
                            else
                            {
                                drProductEdit["ReqHQAppr"] = false;
                            }

                            //drProductEdit["IsActive"] = Convert.ToBoolean(chk_Status.Checked);
                            drProductEdit["IsActive"] = lbl_Status.Text == statusActiveText ? true : false;
                            drProductEdit["TaxAccCode"] = txt_TaxAccCode.Text.Trim();
                            drProductEdit["IsRecipe"] = chk_IsRecipe.Checked;
                            drProductEdit["SaleItem"] = chk_SaleItem.Checked;
                            //drProductEdit["ApprovalLevel"] = ddl_ApprovalLevel.Text == string.Empty ? 0 : Convert.ToInt32(ddl_ApprovalLevel.Text.Split(':')[0]);
                            if (ddl_ApprovalLevel.Text == string.Empty)
                                drProductEdit["ApprovalLevel"] = 0;
                            else
                                drProductEdit["ApprovalLevel"] = ddl_ApprovalLevel.Value;

                            drProductEdit["UpdatedDate"] = ServerDateTime;
                            drProductEdit["UpdatedBy"] = LoginInfo.LoginName;

                            // Added on: 02/04/2018, By: Fon
                            drProductEdit["AddField10"] = (ddl_HQSKU.Value != string.Empty) ? ddl_HQSKU.Value : DBNull.Value;
                            // End Added.

                            // Insert Product code to table IN.ProdUnit
                            if (dsProductEdit.Tables[prodUnit.TableName] != null)
                            {
                                //DataTable dtOrder  = dsProductEdit.Tables["OrderUnit"];
                                //DataTable dtRecipe = dsProductEdit.Tables["RecipeUnit"];

                                for (var i = 0; i < dsProductEdit.Tables[prodUnit.TableName].Rows.Count; i++)
                                {
                                    var drProdUnit = dsProductEdit.Tables[prodUnit.TableName].Rows[i];

                                    if (drProdUnit.RowState != DataRowState.Deleted)
                                    {
                                        drProdUnit["ProductCode"] = txt_Code.Text.Trim();
                                    }
                                }
                            }

                            #region [TransLog]
                            //---------------------------- TransLog --------------------------------------------
                            var drLog = dsProductEdit.Tables[product.TableName].Rows[0];

                            // Arrylist for comibne TableName/FieldName/FieldValue
                            var arrayCombine = new ArrayList();

                            if (Request.Params["MODE"].ToUpper() == "EDIT")
                            {
                                // if the action is edit.action value need to assign for Modify.
                                _action = "Modify";

                                //Check field description.
                                var ENdescOld = drLog[1, DataRowVersion.Original].ToString();
                                if (!ENdescOld.Equals(txt_Description1.Text))
                                {
                                    var activityENdesc = " From " +
                                                             (ENdescOld == string.Empty ? "''" : ENdescOld) +
                                                             " To " + txt_Description1.Text;

                                    // Log information pass by arraylist
                                    arrayCombine.Add(new[] { "IN", "ENProductName", activityENdesc });
                                }

                                var LLdescOld = drLog[2, DataRowVersion.Original].ToString();
                                if (!LLdescOld.Equals(txt_Descritpion2.Text))
                                {
                                    var activityLLdesc = " From " +
                                                             (LLdescOld == string.Empty ? "''" : LLdescOld) +
                                                             " To " + txt_Descritpion2.Text;

                                    // Log information pass by arraylist
                                    arrayCombine.Add(new[] { "IN", "LocalProductName", activityLLdesc });
                                }

                                var taxTypeold = drLog[11, DataRowVersion.Original].ToString();
                                if (!taxTypeold.Equals(ddl_TAXType.Text))
                                {
                                    var activitytaxType = " From " +
                                                             (taxTypeold == string.Empty ? "''" : taxTypeold) +
                                                             " To " + ddl_TAXType.Text;

                                    // Log information pass by arraylist
                                    arrayCombine.Add(new[] { "IN", "TaxType", activitytaxType });
                                }

                                var taxRateold = drLog[12, DataRowVersion.Original].ToString();
                                if (!taxRateold.Equals(txt_TaxRate.Text))
                                {
                                    var activitytaxRate = " From " +
                                                             (taxRateold == string.Empty ? "''" : taxRateold) +
                                                             " To " + txt_TaxRate.Text;

                                    // Log information pass by arraylist
                                    arrayCombine.Add(new[] { "IN", "TaxRate", activitytaxRate });
                                }

                                var taxAccold = drLog[37, DataRowVersion.Original].ToString();
                                if (!taxAccold.Equals(txt_TaxAccCode.Text))
                                {
                                    var activitytaxAcc = " From " +
                                                             (taxAccold == string.Empty ? "''" : taxAccold) +
                                                             " To " + txt_TaxAccCode.Text;

                                    // Log information pass by arraylist
                                    arrayCombine.Add(new[] { "IN", "TaxAccountCode", activitytaxAcc });
                                }

                                var QtyDevold = drLog[15, DataRowVersion.Original].ToString();
                                if (!QtyDevold.Equals(txt_QuantityDeviation.Text))
                                {
                                    var activityQtyDev = " From " +
                                                             (txt_QuantityDeviation.Text == string.Empty ? "''" : QtyDevold) +
                                                             " To " + txt_QuantityDeviation.Text;

                                    // Log information pass by arraylist
                                    arrayCombine.Add(new[] { "IN", "QuantityDeviation", activityQtyDev });
                                }

                                var priceDevold = drLog[16, DataRowVersion.Original].ToString();
                                if (!priceDevold.Equals(txt_PriceDeviation.Text))
                                {
                                    var activitypriceDev = " From " +
                                                             (txt_PriceDeviation.Text == string.Empty ? "''" : priceDevold) +
                                                             " To " + txt_PriceDeviation.Text;

                                    // Log information pass by arraylist
                                    arrayCombine.Add(new[] { "IN", "PriceDeviation", activitypriceDev });

                                }


                            }

                            var dsT = new DataSet();

                            // Get trans log schema.
                            _transLog.GetSchema(dsT, LoginInfo.ConnStr);

                            // Create new row.
                            var drNew = dsT.Tables[_transLog.TableName].NewRow();

                            // Prepare for Insert to accountactlog table.
                            drNew["ID"] = _transLog.GetNewID(hf_ConnStr.Value);
                            drNew["Module"] = "IN";
                            drNew["Submodule"] = "Product";
                            drNew["RefNo"] = dsProductEdit.Tables[product.TableName].Rows[0]["ProductCode"].ToString();
                            drNew["Log"] = Blue.BL.GnxLib.GetXMLFormat(_action, arrayCombine);
                            drNew["CreatedDate"] = ServerDateTime;
                            drNew["CreatedBy"] = LoginInfo.LoginName;

                            // Add new row
                            dsT.Tables[_transLog.TableName].Rows.Add(drNew);

                            var resultLog = _transLog.Save(dsT, hf_ConnStr.Value);


                            #endregion
                        }
                        #endregion
                        #region Create Mode
                        else  // Create
                        {
                            product.GetStructure(dsProductEdit, hf_ConnStr.Value);

                            // New Process
                            var drProductNew = dsProductEdit.Tables["Product"].NewRow();

                            drProductNew["ProductCode"] = product.GetGenerateProductCode(ddl_ItemGroup.SelectedItem.Value, hf_ConnStr.Value);
                            drProductNew["ProductDesc1"] = txt_Description1.Text;
                            drProductNew["ProductDesc2"] = txt_Descritpion2.Text;
                            drProductNew["ProductCate"] = ddl_ItemGroup.SelectedItem.Value;
                            drProductNew["BarCode"] = txt_BarCode.Text;

                            if (txt_RecipeUnit.Text != string.Empty)
                            {
                                drProductNew["RecipeUnit"] = (txt_RecipeUnit.Text);
                            }
                            else
                            {
                                drProductNew["RecipeUnit"] = System.DBNull.Value;
                            }


                            if (cmb_InventoryUnit.Value != null)
                            {
                                drProductNew["InventoryUnit"] = (cmb_InventoryUnit.Value.ToString());
                            }
                            else
                            {
                                drProductNew["InventoryUnit"] = System.DBNull.Value;
                            }

                            if (txt_OrderUnit.Text != string.Empty)
                            {
                                drProductNew["OrderUnit"] = (txt_OrderUnit.Text);
                            }
                            else
                            {
                                drProductNew["OrderUnit"] = (cmb_InventoryUnit.SelectedItem.Value.ToString());
                                //System.DBNull.Value;
                            }

                            drProductNew["TaxType"] = ddl_TAXType.SelectedItem.Value;

                            if (txt_RecipeConverseRate.Text != string.Empty)
                            {
                                drProductNew["RecipeConvInvent"] = Convert.ToDecimal(txt_RecipeConverseRate.Text);
                            }
                            else
                            {
                                drProductNew["RecipeConvInvent"] = 0;
                            }

                            if (txt_InvenConvOrder.Text != string.Empty)
                            {
                                drProductNew["InventoryConvOrder"] = Convert.ToDecimal(txt_InvenConvOrder.Text);
                            }
                            else
                            {
                                drProductNew["InventoryConvOrder"] = 1;
                            }

                            if (ddl_TAXType.SelectedItem.Value == "N")
                            {
                                drProductNew["TaxRate"] = 0;
                            }
                            else if (!string.IsNullOrEmpty(txt_TaxRate.Text) && ddl_TAXType.SelectedItem.Value != "N")
                            {
                                decimal taxRate = 0;
                                decimal.TryParse(txt_TaxRate.Text, out taxRate);
                                drProductNew["TaxRate"] = taxRate;
                            }
                            else
                            {
                                pop_AlertTaxRate.ShowOnPageLoad = true;
                                return;
                            }

                            if (txt_StandardCost.Text != string.Empty)
                            {
                                drProductNew["StandardCost"] = Convert.ToDecimal(txt_StandardCost.Text);
                            }
                            else
                            {
                                drProductNew["StandardCost"] = 0;
                            }

                            if (txt_LastCost.Text != string.Empty)
                            {
                                drProductNew["LastCost"] = Convert.ToDecimal(txt_LastCost.Text);
                            }
                            else
                            {
                                drProductNew["LastCost"] = 0;
                            }

                            if (txt_QuantityDeviation.Text != string.Empty)
                            {
                                drProductNew["QuantityDeviation"] = Convert.ToDecimal(txt_QuantityDeviation.Text);
                            }
                            else
                            {
                                drProductNew["QuantityDeviation"] = 0;
                            }

                            if (txt_PriceDeviation.Text != string.Empty)
                            {
                                drProductNew["PriceDeviation"] = Convert.ToDecimal(txt_PriceDeviation.Text);
                            }
                            else
                            {
                                drProductNew["PriceDeviation"] = 0;
                            }

                            if (chk_ReqHQAppr.Checked)
                            {
                                drProductNew["ReqHQAppr"] = true;
                            }
                            else
                            {
                                drProductNew["ReqHQAppr"] = false;
                            }

                            //drProductNew["IsActive"] = Convert.ToBoolean(chk_Status.Checked);
                            drProductNew["IsActive"] = lbl_Status.Text == statusActiveText ? true : false;
                            drProductNew["TaxAccCode"] = txt_TaxAccCode.Text.Trim();
                            drProductNew["IsRecipe"] = chk_IsRecipe.Checked;
                            drProductNew["SaleItem"] = chk_SaleItem.Checked;
                            if (ddl_ApprovalLevel.Text == string.Empty)
                                drProductNew["ApprovalLevel"] = 0;
                            else
                                drProductNew["ApprovalLevel"] = ddl_ApprovalLevel.Value;
                            drProductNew["CreatedDate"] = ServerDateTime;
                            drProductNew["CreatedBy"] = LoginInfo.LoginName;
                            drProductNew["UpdatedDate"] = ServerDateTime;
                            drProductNew["UpdatedBy"] = LoginInfo.LoginName;

                            // Added on: 02/04/2018, By: Fon
                            drProductNew["AddField10"] = (ddl_HQSKU.Value != string.Empty) ? ddl_HQSKU.Value : DBNull.Value;
                            // End Added.

                            // Add new row
                            dsProductEdit.Tables[product.TableName].Rows.Add(drProductNew);

                            // Insert Product code to table IN.ProdUnit
                            if (dsProductEdit.Tables[prodUnit.TableName] != null)
                            {
                                for (var i = 0; i < dsProductEdit.Tables[prodUnit.TableName].Rows.Count; i++)
                                {
                                    var drProdU = dsProductEdit.Tables[prodUnit.TableName].Rows[i];

                                    if (drProdU.RowState != DataRowState.Deleted)
                                    {
                                        drProdU["ProductCode"] =
                                            dsProductEdit.Tables[product.TableName].Rows[0]["ProductCode"].ToString();
                                    }
                                }

                                var drProdUnitI = dsProductEdit.Tables[prodUnit.TableName].NewRow();
                                drProdUnitI["ProductCode"] =
                                    dsProductEdit.Tables[product.TableName].Rows[0]["ProductCode"].ToString();
                                drProdUnitI["OrderUnit"] = (cmb_InventoryUnit.Value.ToString());
                                drProdUnitI["Rate"] = 1.00;
                                drProdUnitI["IsDefault"] = true;
                                drProdUnitI["UnitType"] = "I";

                                dsProductEdit.Tables[prodUnit.TableName].Rows.Add(drProdUnitI);


                                // Check Default Order Unit

                                DataRow[] dr = dsProductEdit.Tables[prodUnit.TableName].Select("UnitType = 'O' AND IsDefault = 1");

                                if (dr == null)
                                {
                                    var drProdUnit = dsProductEdit.Tables[prodUnit.TableName].NewRow();
                                    drProdUnit["ProductCode"] =
                                        dsProductEdit.Tables[product.TableName].Rows[0]["ProductCode"].ToString();
                                    drProdUnit["OrderUnit"] = (cmb_InventoryUnit.Value.ToString());
                                    drProdUnit["Rate"] = 1.00;
                                    drProdUnit["IsDefault"] = true;
                                    drProdUnit["UnitType"] = "O";

                                    dsProductEdit.Tables[prodUnit.TableName].Rows.Add(drProdUnit);
                                }
                            }
                        }
                        #endregion


                        // Added on: 05/04/2018, By: Fon, For: Update productCode @ HQ table.
                        DataSet dsProdLocHQ = ExceptChanged_ProdLocHQ();
                        bool result = prodLocHQ.Save(dsProdLocHQ, LoginInfo.HQConnStr);
                        // End Added.

                        result = product.SaveProductAndProdUnit(dsProductEdit, hf_ConnStr.Value);
                        if (result)
                        {
                            string productCode = dsProductEdit.Tables[product.TableName].Rows[0]["ProductCode"].ToString();

                            // Update new description to PC.PrDt with DocStatus = 'In Progress'
                            string sql = "UPDATE PC.PrDt";
                            sql += string.Format("   SET DescEn = N'{0}', Descll= N'{1}'", txt_Description1.Text, txt_Descritpion2.Text);
                            sql += " FROM PC.Pr";
                            sql += " JOIN PC.PrDt ON pr.PRNo = PrDt.PRNo";
                            sql += " WHERE pr.DocStatus = 'In Process'";
                            sql += string.Format(" AND PrDt.ProductCode = '{0}'", productCode);

                            prodLoc.DbExecuteQuery(@sql, null, hf_ConnStr.Value);


                            if (Request.Params["MODE"] == "EDIT")
                            {
                                //Response.Redirect("Prod.aspx?BuCode=" + Request.Params["BuCode"].ToString() + "&ID=" + Request.Params["ID"].ToString());
                                Response.Redirect("Prod2.aspx?BuCode=" + Request.Params["BuCode"] + "&ID=" + Request.Params["ID"]);
                            }
                            else
                            {
                                //Response.Redirect("Prod.aspx?BuCode=" + Request.Params["BuCode"].ToString() + "&ID=" + dsProductEdit.Tables[product.TableName].Rows[0]["ProductCode"].ToString());
                                Response.Redirect("Prod2.aspx?BuCode=" + Request.Params["BuCode"] + "&ID=" + productCode);
                            }
                        }
                    }
                    break;


                case "BACK":
                    if (Request.Params["MODE"] == "Edit")
                    {
                        //Response.Redirect("Prod.aspx?BuCode=" + Request.Params["BuCode"].ToString() + "&ID=" + Request.Params["ID"].ToString());
                        Response.Redirect("Prod2.aspx?BuCode=" + Request.Params["BuCode"] + "&ID=" +
                                          Request.Params["ID"]);
                    }
                    else if (Request.Params["MODE"] == "new")
                    {
                        Response.Redirect("ProdList.aspx");
                    }

                    break;
            }
        }

        /******** Start Unit Databinding for poup***************************/

        /// <summary>
        ///     Define statement for create/delete/print
        /// </summary>
        /// <param name="source"></param>
        /// <param name="e"></param>
        protected void menu_ItemClick(object source, DevExpress.Web.ASPxMenu.MenuItemEventArgs e)
        {
            switch (e.Item.Text.ToUpper())
            {
                case "CREATE":
                    Create();
                    break;

                case "DELETE":
                    Delete();
                    break;

                case "CLOSE":
                    //Mdlp_RecipeUnitPopup.Hide();
                    break;
            }
        }

        /// <summary>
        ///     Create New Unit
        /// </summary>
        private void Create()
        {
            grd_Unit.AddNewRow();
            //Mdlp_RecipeUnitPopup.Show();
        }

        /// <summary>
        ///     Display confrim delete Unit
        /// </summary>
        private void Delete()
        {
            if (grd_Unit.Selection.Count > 0)
            {
                //Mdlp_RecipeUnitPopup.Show();
                pop_ConfrimDelete.ShowOnPageLoad = true;
            }
        }

        /// <summary>
        ///     Delete selected Unit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btn_ConfrimDelete_Click(object sender, EventArgs e)
        {
            var columnValues = grd_Unit.GetSelectedFieldValues("UnitCode");

            foreach (DataRow drDeleting in dsUnit.Tables[unit.TableName].Rows)
            {
                if (drDeleting.RowState != DataRowState.Deleted)
                {
                    if (drDeleting["UnitCode"].ToString().ToUpper() == columnValues[0].ToString().ToUpper())
                    {
                        drDeleting.Delete();
                    }
                }
            }

            // Save to database
            var saveUnit = unit.Save(dsUnit, hf_ConnStr.Value);

            if (saveUnit)
            {
                pop_ConfrimDelete.ShowOnPageLoad = false;

                CheckDeletedRow(columnValues[0].ToString());

                RefreshUnitDataBinding();

                Page_Retrieve();
            }
        }

        /// <summary>
        ///     Check deleted row is selected in combo box.
        /// </summary>
        private void CheckDeletedRow(string UnitCode)
        {
            // Checking poup deleted row is selected in combo box or not.
            // If selected, clear selected value in combo box.
            //if (cmb_RecipeUnit.SelectedIndex >= 0)
            //{
            //    if (cmb_RecipeUnit.SelectedItem.Value.ToString().ToUpper() == UnitCode.ToString().ToUpper())
            //    {
            //        cmb_RecipeUnit.Value = string.Empty;
            //    }
            //}

            //if (cmb_OrderUnit.SelectedIndex >= 0)
            //{
            //    if (cmb_OrderUnit.SelectedItem.Value.ToString().ToUpper() == UnitCode.ToString().ToUpper())
            //    {
            //        cmb_OrderUnit.Value = string.Empty;
            //    }
            //}

            if (cmb_InventoryUnit.SelectedIndex >= 0)
            {
                if (cmb_InventoryUnit.SelectedItem.Value.ToString().ToUpper() == UnitCode.ToUpper())
                {
                    cmb_InventoryUnit.Value = string.Empty;
                }
            }
        }

        /// <summary>
        ///     No click process, closed poup dialogue.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btn_ConfrimDeleteNo_Click(object sender, EventArgs e)
        {
            grd_Unit.Selection.UnselectAll();
            pop_ConfrimDelete.ShowOnPageLoad = false;
        }

        /* End Unit Databinding for poup*/

        protected void btn_OK_Click(object sender, EventArgs e)
        {
            pop_AlertTaxRate.ShowOnPageLoad = false;
        }

        // -- Inactive/Active Product
        //private bool checkActiveProduct(string productCode)
        //{
        //    SqlConnection conn = new SqlConnection(LoginInfo.ConnStr);
        //    conn.Open();

        //    string sql = "EXEC [IN].IsAbleToInactiveProduct '" + productCode + "'";
        //    SqlCommand cmd = new SqlCommand(sql, conn);
        //    SqlDataReader reader = cmd.ExecuteReader();
        //    reader.Read();
        //    if (reader["RecordCount"].ToString() == "0")
        //        return false;
        //    else
        //        return true;
        //}


        private void SetActiveProduct(bool isActive)
        {
            btn_Status.Text = String.Format("Set to {0}", (isActive ? statusInactiveText : statusActiveText).ToString());
            btn_Status.ForeColor = isActive ? Color.Red : Color.Blue;

            lbl_Status.Text = isActive ? statusActiveText : statusInactiveText;
            lbl_Status.ForeColor = isActive ? Color.Blue : Color.Red;
        }


        protected void btn_Status_Click(object sender, EventArgs e)
        {
            if (lbl_Status.Text == statusInactiveText)
            {
                chk_Status.Checked = true;
                SetActiveProduct(true);
            }
            else
            {
                pop_ConfirmStatus.ShowOnPageLoad = true;
            }


        }

        protected void btn_ConfirmStatus_Ok_Click(object sender, EventArgs e)
        {
            bool isInActiveProduct = product.IsAbleToInactiveProduct(txt_Code.Text, LoginInfo.ConnStr);

            if (isInActiveProduct == true)
            {
                SetActiveProduct(false);
                pop_ConfirmStatus.ShowOnPageLoad = false;
            }
            else
            {
                SetActiveProduct(true);

                pop_FailToInactive.ShowOnPageLoad = true;
            }

        }

        protected void btn_ConfirmStatus_Cancel_Click(object sender, EventArgs e)
        {
            pop_ConfirmStatus.ShowOnPageLoad = false;
            pop_FailToInactive.ShowOnPageLoad = false;
        }


        //protected void lnkb_New_Click(object sender, EventArgs e)
        //{
        //    // Show popup
        //    pop_ProdUnit.ShowOnPageLoad = true;
        //}

        protected void ddl_Product_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dsProductEdit.Tables["UnitList"] != null)
            {
                dsProductEdit.Tables["UnitList"].Clear();
            }

            //bool getUnit = prodUnit.GetUnitList(dsProductEdit, ddl_Product.SelectedItem.Value, hf_ConnStr.Value);

            //if (getUnit)
            //{
            //    grd_UnitList.DataSource = dsProductEdit.Tables["UnitList"];
            //    grd_UnitList.DataBind();
            //}

            Session["dsProductEdit"] = dsProductEdit;
        }

        //protected void grd_UnitList_RowDataBound(object sender, GridViewRowEventArgs e)
        //{
        //    if (e.Row.RowType == DataControlRowType.DataRow)
        //    {
        //        if (e.Row.FindControl("chk_Selected") != null)
        //        {
        //            CheckBox chk_Selected = e.Row.FindControl("chk_Selected") as CheckBox;
        //            chk_Selected.Checked = bool.Parse(DataBinder.Eval(e.Row.DataItem, "Selected").ToString());
        //        }
        //    }
        //}

        //protected void btn_OK_ProdUnit_Click(object sender, EventArgs e)
        //{
        //    dsProductEdit = (DataSet)Session["dsProductEdit"];

        //    if (dsProductEdit != null)
        //    {
        //        for (int i = dsProductEdit.Tables[prodUnit.TableName].Rows.Count - 1; i >= 0; i--)
        //        {
        //            DataRow drProdUnit = dsProductEdit.Tables[prodUnit.TableName].Rows[i];                   
        //            drProdUnit.Delete();                  
        //        }

        //        // Check base unit required by check only one rate = 1.00
        //        int baseUnitCount = 0;

        //        foreach (GridViewRow gvr_UnitList in grd_UnitList.Rows)
        //        {
        //            // Insert new conversion rate (only selected unit which rate not equal to 0)  
        //            CheckBox chk_Selected   = gvr_UnitList.FindControl("chk_Selected") as CheckBox;
        //            Label lbl_Unit          = gvr_UnitList.FindControl("lbl_Unit") as Label;
        //            TextBox txt_Rate        = gvr_UnitList.FindControl("txt_Rate") as TextBox;

        //            if (chk_Selected.Checked)
        //            {
        //                if (decimal.Parse(txt_Rate.Text.Trim()) != 0)
        //                {
        //                    DataRow drNewProdUnit        = dsProductEdit.Tables[prodUnit.TableName].NewRow();
        //                    drNewProdUnit["ProductCode"] = txt_Code.Text;
        //                    drNewProdUnit["OrderUnit"]   = lbl_Unit.Text;
        //                    drNewProdUnit["Rate"]        = decimal.Parse(txt_Rate.Text.Trim());

        //                    dsProductEdit.Tables[prodUnit.TableName].Rows.Add(drNewProdUnit);

        //                    if (decimal.Parse(txt_Rate.Text.Trim()) == 1)
        //                    {
        //                        baseUnitCount++;
        //                    }
        //                }
        //            }
        //        }

        //        if (baseUnitCount == 0)
        //        {
        //            // Display error message : There is no base unit assign
        //            lbl_Error.Text = "There is no base unit assign (Rate=1)";
        //            pop_Error.ShowOnPageLoad = true;
        //            return;
        //        }          

        //        //pop_ProdUnit.ShowOnPageLoad = false;

        //        //grd_ProdUnit.DataSource = dsProductEdit.Tables[prodUnit.TableName];
        //        //grd_ProdUnit.DataBind();

        //    }
        //}

        //protected void btn_Cancel_ProdUnit_Click(object sender, EventArgs e)
        //{
        //    pop_ProdUnit.ShowOnPageLoad = false;
        //}

        protected void imb_CreateOrder_Click(object sender, ImageClickEventArgs e)
        {
            if (dsProductEdit.Tables["OrderUnit"] != null)
            {
                var drAdd = dsProductEdit.Tables["OrderUnit"].NewRow();
                drAdd["ProductCode"] = string.Empty;
                drAdd["OrderUnit"] = string.Empty;
                drAdd["UnitType"] = "O";
                drAdd["Rate"] = 0.0;
                dsProductEdit.Tables["OrderUnit"].Rows.Add(drAdd);

                grd_OrderUnit1.DataSource = dsProductEdit.Tables["OrderUnit"];
                grd_OrderUnit1.EditIndex = dsProductEdit.Tables["OrderUnit"].Rows.Count - 1;
                grd_OrderUnit1.DataBind();

                menu_CmdBar.Items.FindByName("Save").Visible = false;
                UnitMode = "NEW";
            }
        }

        protected void imb_DeleteOrder_Click(object sender, ImageClickEventArgs e)
        {
            dsProductEdit = (DataSet)Session["dsProductEdit"];

            for (var i = grd_OrderUnit1.Rows.Count - 1; i >= 0; i--)
            {
                var Chk_Item = grd_OrderUnit1.Rows[i].Cells[0].FindControl("Chk_Item") as CheckBox;

                if (Chk_Item.Checked)
                {
                    dsProductEdit.Tables["OrderUnit"].Rows[i].Delete();
                }
            }

            grd_OrderUnit1.DataSource = dsProductEdit.Tables["OrderUnit"];
            grd_OrderUnit1.DataBind();
        }

        protected void grd_OrderUnit1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (grd_OrderUnit1.EditIndex != -1)
            {
                imb_CreateOrder.Visible = false;
                imb_DeleteOrder.Visible = false;
            }
            else
            {
                imb_CreateOrder.Visible = true;
                imb_DeleteOrder.Visible = true;
            }
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                // Code.
                if (e.Row.FindControl("lbl_OrderUnit") != null)
                {
                    var lbl_OrderUnit = e.Row.FindControl("lbl_OrderUnit") as Label;
                    lbl_OrderUnit.Text = DataBinder.Eval(e.Row.DataItem, "OrderUnit").ToString();
                }
                if (e.Row.FindControl("ddl_OrderUnit") != null)
                {
                    var ddl_OrderUnit = e.Row.FindControl("ddl_OrderUnit") as ASPxComboBox;
                    ddl_OrderUnit.DataSource = unit.GetList(hf_ConnStr.Value);
                    ddl_OrderUnit.TextField = "Name";
                    ddl_OrderUnit.ValueField = "UnitCode";
                    ddl_OrderUnit.DataBind();
                    ddl_OrderUnit.Value = DataBinder.Eval(e.Row.DataItem, "OrderUnit").ToString();
                }

                // Description.
                if (e.Row.FindControl("lbl_OrderRate") != null)
                {
                    var lbl_OrderRate = e.Row.FindControl("lbl_OrderRate") as Label;
                    lbl_OrderRate.Text = DataBinder.Eval(e.Row.DataItem, "Rate").ToString();
                }
                if (e.Row.FindControl("txt_OrderRate") != null)
                {
                    var txt_OrderRate = e.Row.FindControl("txt_OrderRate") as TextBox;
                    txt_OrderRate.Text = DataBinder.Eval(e.Row.DataItem, "Rate").ToString();
                }

                // IsAvctived.
                if (e.Row.FindControl("Img_Btn_ChkBox") != null)
                {
                    var Img_Btn_ChkBox = e.Row.FindControl("Img_Btn_ChkBox") as ImageButton;
                    Img_Btn_ChkBox.Enabled = false;

                    if (DataBinder.Eval(e.Row.DataItem, "IsDefault").ToString() != string.Empty)
                    {
                        Img_Btn_ChkBox.ImageUrl = Convert.ToBoolean(DataBinder.Eval(e.Row.DataItem, "IsDefault"))
                            ? "~/App_Themes/Default/Images/IN/STDREQ/chk_True.png"
                            : "~/App_Themes/Default/Images/IN/STDREQ/chk_False.png";
                    }
                    else
                    {
                        Img_Btn_ChkBox.ImageUrl = "~/App_Themes/Default/Images/IN/STDREQ/chk_False.png";
                    }
                }
                if (e.Row.FindControl("chk_Default") != null)
                {
                    var chk_Actived = e.Row.FindControl("chk_Default") as CheckBox;

                    if (DataBinder.Eval(e.Row.DataItem, "IsDefault") != DBNull.Value)
                    {
                        chk_Actived.Checked = Convert.ToBoolean(DataBinder.Eval(e.Row.DataItem, "IsDefault"));
                    }
                    else
                    {
                        chk_Actived.Checked = false;
                    }
                }
            }
        }

        protected void grd_OrderUnit1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            dsProductEdit = (DataSet)Session["dsProductEdit"];

            var strProductCode = string.Empty;

            var ddl_OrderUnit = grd_OrderUnit1.Rows[e.RowIndex].FindControl("ddl_OrderUnit") as ASPxComboBox;
            var txt_OrderRate = grd_OrderUnit1.Rows[e.RowIndex].FindControl("txt_OrderRate") as TextBox;
            var chk_Default = grd_OrderUnit1.Rows[e.RowIndex].FindControl("chk_Default") as CheckBox;


            if (Request.Params["MODE"].ToUpper() == "EDIT")
            {
                strProductCode = txt_Code.Text;
            }

            if (UnitMode == "NEW")
            {
                var drNew = dsProductEdit.Tables["OrderUnit"].Rows[grd_OrderUnit1.EditIndex];

                drNew["ProductCode"] = strProductCode;
                if (ddl_OrderUnit != null) drNew["OrderUnit"] = ddl_OrderUnit.Value;

                if (txt_OrderRate != null && txt_OrderRate.Text != string.Empty)
                {
                    drNew["Rate"] = decimal.Parse(txt_OrderRate.Text);
                }
                else
                {
                    drNew["Rate"] = decimal.Parse("1");
                }

                drNew["UnitType"] = "O";
                drNew["IsDefault"] = chk_Default != null && chk_Default.Checked;
            }
            else
            {
                if (chk_Default != null && chk_Default.Checked)
                {
                    if (dsProductEdit.Tables["OrderUnit"].Rows.Count > 0)
                    {
                        for (var jj = 0; jj < dsProductEdit.Tables["OrderUnit"].Rows.Count; jj++)
                        {
                            var drChk = dsProductEdit.Tables["OrderUnit"].Rows[jj];

                            if (jj != grd_OrderUnit1.EditIndex)
                            {
                                drChk["IsDefault"] = false;
                            }
                        }
                    }
                }

                var drUpdating = dsProductEdit.Tables["OrderUnit"].Rows[e.RowIndex];

                if (ddl_OrderUnit != null && ddl_OrderUnit.SelectedItem != null)
                    drUpdating["OrderUnit"] = ddl_OrderUnit.SelectedItem.Value;
                if (txt_OrderRate != null && txt_OrderRate.Text != string.Empty)
                {
                    drUpdating["Rate"] = decimal.Parse(txt_OrderRate.Text);
                }
                else
                {
                    drUpdating["Rate"] = decimal.Parse("1");
                }
                //drUpdating["Rate"]      = decimal.Parse(txt_OrderRate.Text.ToString());
                drUpdating["UnitType"] = "O";
                drUpdating["IsDefault"] = chk_Default != null && chk_Default.Checked;
            }

            grd_OrderUnit1.DataSource = dsProductEdit.Tables["OrderUnit"];
            grd_OrderUnit1.EditIndex = -1;
            grd_OrderUnit1.DataBind();

            UnitMode = string.Empty;
            menu_CmdBar.Items.FindByName("Save").Visible = true;

            Session["dsProductEdit"] = dsProductEdit;
        }

        protected void grd_OrderUnit1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            dsProductEdit = (DataSet)Session["dsProductEdit"];

            if (UnitMode == "NEW")
            {
                dsProductEdit.Tables["OrderUnit"].Rows[dsProductEdit.Tables["OrderUnit"].Rows.Count - 1].Delete();
            }

            if (UnitMode == "EDIT")
            {
                dsProductEdit.Tables[prodUnit.TableName].Rows[dsProductEdit.Tables["OrderUnit"].Rows.Count - 1]
                    .CancelEdit();
            }

            if (dsProductEdit.Tables["OrderUnit"].Rows.Count > 0)
            {
                for (var ii = 0; ii < dsProductEdit.Tables["OrderUnit"].Rows.Count; ii++)
                {
                    var drOrderUnit = dsProductEdit.Tables["OrderUnit"].Rows[ii];

                    if ((bool)drOrderUnit["IsDefault"])
                    {
                        txt_OrderUnit.Text = drOrderUnit["OrderUnit"].ToString();
                        txt_InvenConvOrder.Text = drOrderUnit["Rate"].ToString();
                    }
                }
            }

            grd_OrderUnit1.DataSource = dsProductEdit.Tables["OrderUnit"];
            grd_OrderUnit1.EditIndex = -1;
            grd_OrderUnit1.DataBind();

            UnitMode = string.Empty;
            menu_CmdBar.Items.FindByName("Save").Visible = true;

            Session["dsProductEdit"] = dsProductEdit;
        }

        protected void grd_OrderUnit1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            dsProductEdit = (DataSet)Session["dsProductEdit"];

            grd_OrderUnit1.DataSource = dsProductEdit.Tables["OrderUnit"];
            grd_OrderUnit1.EditIndex = e.NewEditIndex;
            grd_OrderUnit1.DataBind();

            for (var i = grd_OrderUnit1.Rows.Count - 1; i >= 0; i--)
            {
                var Chk_Item = grd_OrderUnit1.Rows[i].Cells[0].FindControl("Chk_Item") as CheckBox;
                var Chk_All = grd_OrderUnit1.HeaderRow.FindControl("Chk_All") as CheckBox;

                if (Chk_All != null) Chk_All.Enabled = false;
                if (Chk_Item != null) Chk_Item.Enabled = false;
            }

            //imb_CreateOrder.Enabled = false;
            //imb_DeleteOrder.Enabled = false;

            UnitMode = "EDIT";
            menu_CmdBar.Items.FindByName("Save").Visible = false;

            Session["dsProductEdit"] = dsProductEdit;
        }

        //protected void cmb_OrderUnit_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    if (dsProductEdit.Tables["OrderUnit"].Rows.Count > 0)
        //    {
        //        for (int xx = 0; xx < dsProductEdit.Tables["OrderUnit"].Rows.Count; xx++ )
        //        {
        //            DataRow drChk = dsProductEdit.Tables["OrderUnit"].Rows[xx];

        //            if (drChk["IsDefault"].ToString() == "True")
        //            {
        //                drChk["OrderUnit"] = cmb_OrderUnit.SelectedItem.Value.ToString();
        //                drChk["Rate"]      = Decimal.Parse(txt_InvenConvOrder.Text.ToString());
        //            }
        //        }
        //    }

        //    grd_OrderUnit1.DataSource = dsProductEdit.Tables["OrderUnit"];
        //    grd_OrderUnit1.DataBind();

        //    Session["dsProductEdit"] = dsProductEdit;     
        //}

        //protected void txt_InvenConvOrder_TextChanged(object sender, EventArgs e)
        //{
        //    if (dsProductEdit.Tables["OrderUnit"].Rows.Count > 0)
        //    {
        //        for (int xx = 0; xx < dsProductEdit.Tables["OrderUnit"].Rows.Count; xx++)
        //        {
        //            DataRow drChk = dsProductEdit.Tables["OrderUnit"].Rows[xx];

        //            if (drChk["IsDefault"].ToString() == "True")
        //            {
        //                drChk["OrderUnit"]  = cmb_OrderUnit.SelectedItem.Value.ToString();
        //                drChk["Rate"]       = Decimal.Parse(txt_InvenConvOrder.Text.ToString());
        //            }
        //        }
        //    }

        //    grd_OrderUnit1.DataSource = dsProductEdit.Tables["OrderUnit"];
        //    grd_OrderUnit1.DataBind();

        //    Session["dsProductEdit"] = dsProductEdit;   
        //}

        protected void chk_Default_CheckedChanged(object sender, EventArgs e)
        {
            var chk_DefaultO = sender as CheckBox;
            if (chk_DefaultO != null)
            {
                var selectedRow = chk_DefaultO.Parent.Parent as GridViewRow;

                for (var j = 0; j <= grd_OrderUnit1.Rows.Count - 1; j++)
                {
                    //CheckBox chk_Default        = grd_OrderUnit1.Rows[j].FindControl("chk_Default") as CheckBox;

                    var Img_Btn_ChkBox = grd_OrderUnit1.Rows[j].FindControl("Img_Btn_ChkBox") as ImageButton;

                    var lbl_OrderUnit = grd_OrderUnit1.Rows[j].FindControl("lbl_OrderUnit") as Label;
                    var lbl_OrderRate = grd_OrderUnit1.Rows[j].FindControl("lbl_OrderRate") as Label;
                    var txt_OrderRate = grd_OrderUnit1.Rows[j].FindControl("txt_OrderRate") as TextBox;
                    var ddl_OrderUnit = grd_OrderUnit1.Rows[j].FindControl("ddl_OrderUnit") as ASPxComboBox;

                    //Img_Btn_ChkBox.Enabled = false;

                    if (selectedRow != null && j != selectedRow.RowIndex)
                    {
                        //chk_Default.Checked = false;
                        if (Img_Btn_ChkBox != null)
                        {
                            Img_Btn_ChkBox.ImageUrl = "~/App_Themes/Default/Images/IN/STDREQ/chk_False.png";
                        }

                        //dsProductEdit.Tables["OrderUnit"].Rows[j]["IsDefault"] = false;
                    }
                    else
                    {
                        //chk_Default.Checked = true;

                        if (lbl_OrderUnit != null)
                        {
                            txt_OrderUnit.Text = lbl_OrderUnit.Text;
                            if (lbl_OrderRate != null) txt_InvenConvOrder.Text = lbl_OrderRate.Text;
                        }
                        else
                        {
                            if (ddl_OrderUnit != null) txt_OrderUnit.Text = ddl_OrderUnit.Value.ToString();
                            if (txt_OrderRate != null) txt_InvenConvOrder.Text = txt_OrderRate.Text;
                        }

                        if (Img_Btn_ChkBox != null)
                        {
                            Img_Btn_ChkBox.ImageUrl = "~/App_Themes/Default/Images/IN/STDREQ/chk_True.png";
                        }

                        //dsProductEdit.Tables["OrderUnit"].Rows[j]["IsDefault"] = true;
                    }

                    //Session["dsProductEdit"] = dsProductEdit;
                }
            }
        }

        protected void imb_CreateRecipe_Click(object sender, ImageClickEventArgs e)
        {
            if (dsProductEdit.Tables["RecipeUnit"] != null)
            {
                var drAdd = dsProductEdit.Tables["RecipeUnit"].NewRow();
                drAdd["ProductCode"] = string.Empty;
                drAdd["OrderUnit"] = string.Empty;
                drAdd["UnitType"] = "R";

                dsProductEdit.Tables["RecipeUnit"].Rows.Add(drAdd);

                grd_RecipeUnit.DataSource = dsProductEdit.Tables["RecipeUnit"];
                grd_RecipeUnit.EditIndex = dsProductEdit.Tables["RecipeUnit"].Rows.Count - 1;
                grd_RecipeUnit.DataBind();

                menu_CmdBar.Items.FindByName("Save").Visible = false;
                UnitMode = "NEW";
            }
        }

        protected void imb_DeleteRecipe_Click(object sender, ImageClickEventArgs e)
        {
            dsProductEdit = (DataSet)Session["dsProductEdit"];

            for (var i = grd_RecipeUnit.Rows.Count - 1; i >= 0; i--)
            {
                var Chk_Item = grd_RecipeUnit.Rows[i].Cells[0].FindControl("Chk_Item") as CheckBox;

                if (Chk_Item.Checked)
                {
                    dsProductEdit.Tables["RecipeUnit"].Rows[i].Delete();
                }
            }

            grd_RecipeUnit.DataSource = dsProductEdit.Tables["RecipeUnit"];
            grd_RecipeUnit.DataBind();
        }

        protected void grd_RecipeUnit_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            // Modified on: 11/09/2017, By: Fon
            imb_CreateRecipe.Visible = true;
            imb_DeleteRecipe.Visible = true;

            if (grd_RecipeUnit.EditIndex != -1)
            {
                imb_CreateRecipe.Visible = false;
                imb_DeleteRecipe.Visible = false;
            }
            // End Modified.

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                // Code.
                if (e.Row.FindControl("lbl_ReciUnit") != null)
                {
                    var lbl_ReciUnit = e.Row.FindControl("lbl_ReciUnit") as Label;
                    if (lbl_ReciUnit != null)
                        lbl_ReciUnit.Text = DataBinder.Eval(e.Row.DataItem, "OrderUnit").ToString();
                }
                if (e.Row.FindControl("ddl_ReciUnit") != null)
                {
                    //var ddl_ReciUnit = e.Row.FindControl("ddl_ReciUnit") as ASPxComboBox;  DropDownList;
                    //if (ddl_ReciUnit != null)
                    //{
                    //ddl_ReciUnit.DataSource = unit.GetList(hf_ConnStr.Value);
                    //    ddl_ReciUnit.DataTextField = "Name";
                    //    ddl_ReciUnit.DataValueField = "UnitCode";
                    //    ddl_ReciUnit.DataBind();
                    //    ddl_ReciUnit.SelectedValue = DataBinder.Eval(e.Row.DataItem, "OrderUnit").ToString();
                    //}
                    var ddl_ReciUnit = e.Row.FindControl("ddl_ReciUnit") as ASPxComboBox;
                    ddl_ReciUnit.DataSource = unit.GetList(hf_ConnStr.Value);
                    ddl_ReciUnit.TextField = "Name";
                    ddl_ReciUnit.ValueField = "UnitCode";
                    ddl_ReciUnit.DataBind();
                    ddl_ReciUnit.Value = DataBinder.Eval(e.Row.DataItem, "OrderUnit").ToString();
                }

                // Description.

                var lbl_ReciRate = e.Row.FindControl("lbl_ReciRate") as Label;
                if (lbl_ReciRate != null) lbl_ReciRate.Text = DataBinder.Eval(e.Row.DataItem, "Rate").ToString();


                var txt_ReciRate = e.Row.FindControl("txt_ReciRate") as TextBox;
                if (txt_ReciRate != null) txt_ReciRate.Text = DataBinder.Eval(e.Row.DataItem, "Rate").ToString();


                // IsAvctived.

                var Img_Btn_ChkBox = e.Row.FindControl("Img_Btn_ChkBox") as ImageButton;
                if (Img_Btn_ChkBox != null)
                {
                    Img_Btn_ChkBox.Enabled = false;

                    Img_Btn_ChkBox.ImageUrl = Convert.ToBoolean(DataBinder.Eval(e.Row.DataItem, "IsDefault"))
                        ? "~/App_Themes/Default/Images/IN/STDREQ/chk_True.png"
                        : "~/App_Themes/Default/Images/IN/STDREQ/chk_False.png";
                }


                var chk_Actived = e.Row.FindControl("chk_Default") as CheckBox;
                if (chk_Actived != null)
                    chk_Actived.Checked = DataBinder.Eval(e.Row.DataItem, "IsDefault") != DBNull.Value &&
                                          Convert.ToBoolean(DataBinder.Eval(e.Row.DataItem, "IsDefault"));
            }
        }

        protected void grd_RecipeUnit_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            dsProductEdit = (DataSet)Session["dsProductEdit"];

            var strProductCode = string.Empty;

            //var ddl_ReciUnit = grd_RecipeUnit.Rows[e.RowIndex].FindControl("ddl_ReciUnit") as DropDownList;
            var ddl_ReciUnit = grd_RecipeUnit.Rows[e.RowIndex].FindControl("ddl_ReciUnit") as ASPxComboBox;
            var txt_ReciRate = grd_RecipeUnit.Rows[e.RowIndex].FindControl("txt_ReciRate") as TextBox;
            var chk_DefaultR = grd_RecipeUnit.Rows[e.RowIndex].FindControl("chk_DefaultR") as CheckBox;

            if (Request.Params["MODE"].ToUpper() == "EDIT")
            {
                strProductCode = txt_Code.Text;
            }

            if (UnitMode == "NEW")
            {
                var drNew = dsProductEdit.Tables["RecipeUnit"].Rows[grd_RecipeUnit.EditIndex];

                drNew["ProductCode"] = strProductCode;
                //if (ddl_ReciUnit != null) drNew["OrderUnit"] = ddl_ReciUnit.SelectedItem.Value;
                if (ddl_ReciUnit != null) drNew["OrderUnit"] = ddl_ReciUnit.Value;
                if (txt_ReciRate != null) drNew["Rate"] = string.IsNullOrEmpty(txt_ReciRate.Text) ? 1 : decimal.Parse(txt_ReciRate.Text);
                drNew["UnitType"] = "R";
                drNew["IsDefault"] = chk_DefaultR != null && chk_DefaultR.Checked;
            }
            else
            {
                if (chk_DefaultR != null && chk_DefaultR.Checked)
                {
                    if (dsProductEdit.Tables["RecipeUnit"].Rows.Count > 0)
                    {
                        for (var jj = 0; jj < dsProductEdit.Tables["RecipeUnit"].Rows.Count; jj++)
                        {
                            var drChk = dsProductEdit.Tables["RecipeUnit"].Rows[jj];

                            if (jj != grd_RecipeUnit.EditIndex)
                            {
                                drChk["IsDefault"] = false;
                            }
                        }
                    }
                }

                var drUpdating = dsProductEdit.Tables["RecipeUnit"].Rows[e.RowIndex];

                if (ddl_ReciUnit != null && ddl_ReciUnit.SelectedItem != null)
                    drUpdating["OrderUnit"] = ddl_ReciUnit.SelectedItem.Value;
                if (txt_ReciRate != null) drUpdating["Rate"] = string.IsNullOrEmpty(txt_ReciRate.Text) ? 1 : decimal.Parse(txt_ReciRate.Text);
                drUpdating["UnitType"] = "R";
                drUpdating["IsDefault"] = chk_DefaultR != null && chk_DefaultR.Checked;
            }

            grd_RecipeUnit.DataSource = dsProductEdit.Tables["RecipeUnit"];
            grd_RecipeUnit.EditIndex = -1;
            grd_RecipeUnit.DataBind();

            UnitMode = string.Empty;
            menu_CmdBar.Items.FindByName("Save").Visible = true;

            Session["dsProductEdit"] = dsProductEdit;
        }

        protected void grd_RecipeUnit_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            dsProductEdit = (DataSet)Session["dsProductEdit"];

            if (UnitMode == "NEW")
            {
                dsProductEdit.Tables["RecipeUnit"].Rows[dsProductEdit.Tables["RecipeUnit"].Rows.Count - 1].Delete();
            }

            if (UnitMode == "EDIT")
            {
                dsProductEdit.Tables["RecipeUnit"].Rows[dsProductEdit.Tables["RecipeUnit"].Rows.Count - 1].CancelEdit();
            }

            if (dsProductEdit.Tables["RecipeUnit"].Rows.Count > 0)
            {
                for (var ii = 0; ii < dsProductEdit.Tables["RecipeUnit"].Rows.Count; ii++)
                {
                    var drProductUnit = dsProductEdit.Tables["RecipeUnit"].Rows[ii];

                    if ((bool)drProductUnit["IsDefault"])
                    {
                        txt_RecipeUnit.Text = drProductUnit["OrderUnit"].ToString();
                        txt_RecipeConverseRate.Text = drProductUnit["Rate"].ToString();
                    }
                }
            }

            grd_RecipeUnit.DataSource = dsProductEdit.Tables["RecipeUnit"];
            grd_RecipeUnit.EditIndex = -1;
            grd_RecipeUnit.DataBind();

            UnitMode = string.Empty;
            menu_CmdBar.Items.FindByName("Save").Visible = true;

            Session["dsProductEdit"] = dsProductEdit;
        }

        protected void grd_RecipeUnit_RowEditing(object sender, GridViewEditEventArgs e)
        {
            dsProductEdit = (DataSet)Session["dsProductEdit"];

            grd_RecipeUnit.DataSource = dsProductEdit.Tables["RecipeUnit"];
            grd_RecipeUnit.EditIndex = e.NewEditIndex;
            grd_RecipeUnit.DataBind();

            for (var i = grd_RecipeUnit.Rows.Count - 1; i >= 0; i--)
            {
                var Chk_Item = grd_RecipeUnit.Rows[i].Cells[0].FindControl("Chk_Item") as CheckBox;
                var Chk_All = grd_RecipeUnit.HeaderRow.FindControl("Chk_All") as CheckBox;

                if (Chk_All != null) Chk_All.Enabled = false;
                if (Chk_Item != null) Chk_Item.Enabled = false;
            }

            imb_CreateRecipe.Enabled = false;
            imb_DeleteRecipe.Enabled = false;

            UnitMode = "EDIT";
            menu_CmdBar.Items.FindByName("Save").Visible = false;

            Session["dsProductEdit"] = dsProductEdit;
        }

        //protected void cmb_RecipeUnit_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    if (dsProductEdit.Tables["RecipeUnit"].Rows.Count > 0)
        //    {
        //        for (int xx = 0; xx < dsProductEdit.Tables["RecipeUnit"].Rows.Count; xx++)
        //        {
        //            DataRow drChk = dsProductEdit.Tables["RecipeUnit"].Rows[xx];

        //            if (drChk["IsDefault"].ToString() == "True")
        //            {
        //                drChk["OrderUnit"] = cmb_RecipeUnit.SelectedItem.Value.ToString();
        //                drChk["Rate"]      = Decimal.Parse(txt_RecipeConverseRate.Text.ToString());
        //            }
        //        }
        //    }

        //    grd_RecipeUnit.DataSource = dsProductEdit.Tables["RecipeUnit"];
        //    grd_RecipeUnit.DataBind();

        //    Session["dsProductEdit"] = dsProductEdit;  
        //}

        //protected void txt_RecipeConverseRate_NumberChanged(object sender, EventArgs e)
        //{
        //    if (dsProductEdit.Tables["RecipeUnit"].Rows.Count > 0)
        //    {
        //        for (int xx = 0; xx < dsProductEdit.Tables["RecipeUnit"].Rows.Count; xx++)
        //        {
        //            DataRow drChk = dsProductEdit.Tables["RecipeUnit"].Rows[xx];

        //            if (drChk["IsDefault"].ToString() == "True")
        //            {
        //                drChk["OrderUnit"] = cmb_RecipeUnit.SelectedItem.Value.ToString();
        //                drChk["Rate"]      = Decimal.Parse(txt_RecipeConverseRate.Text.ToString());
        //            }
        //        }
        //    }

        //    grd_RecipeUnit.DataSource = dsProductEdit.Tables["RecipeUnit"];
        //    grd_RecipeUnit.DataBind();

        //    Session["dsProductEdit"] = dsProductEdit;   
        //}

        private void PrepareProdUnit()
        {
            var dsMerge = (DataSet)Session["dsProductEdit"];

            if (Request.Params["MODE"].ToUpper() == "EDIT")
            {
                if (dsProductEdit.Tables[prodUnit.TableName] != null)
                {
                    if (dsProductEdit.Tables[prodUnit.TableName].Rows.Count > 0)
                    {
                        for (var ii = 0; ii <= dsProductEdit.Tables[prodUnit.TableName].Rows.Count - 1; ii++)
                        {
                            var drProdUnit = dsProductEdit.Tables[prodUnit.TableName].Rows[ii];

                            drProdUnit.Delete();
                        }
                    }
                }
            }
            else
            {
                dsProductEdit.Tables[prodUnit.TableName].Clear();
            }

            if (dsMerge.Tables["OrderUnit"].Rows.Count > 0)
            {
                for (var i = 0; i <= dsMerge.Tables["OrderUnit"].Rows.Count - 1; i++)
                {
                    var drOrderUnit = dsMerge.Tables["OrderUnit"].Rows[i];

                    if (drOrderUnit.RowState != DataRowState.Deleted)
                    {
                        var dataTable = dsProductEdit.Tables[prodUnit.TableName];
                        if (dataTable != null)
                        {
                            var drAdd = dataTable.NewRow();
                            drAdd["ProductCode"] = string.Empty;
                            drAdd["OrderUnit"] = drOrderUnit["OrderUnit"];
                            drAdd["Rate"] = drOrderUnit["Rate"];
                            drAdd["IsDefault"] = drOrderUnit["IsDefault"];
                            drAdd["UnitType"] = drOrderUnit["UnitType"];

                            dataTable.Rows.Add(drAdd);
                        }
                    }
                }
            }

            if (dsMerge.Tables["RecipeUnit"].Rows.Count > 0)
            {
                for (var i = 0; i <= dsMerge.Tables["RecipeUnit"].Rows.Count - 1; i++)
                {
                    var drRecipeUnit = dsMerge.Tables["RecipeUnit"].Rows[i];

                    if (drRecipeUnit.RowState != DataRowState.Deleted)
                    {
                        var dataTable = dsProductEdit.Tables[prodUnit.TableName];
                        if (dataTable != null)
                        {
                            var drAdd = dataTable.NewRow();
                            drAdd["ProductCode"] = string.Empty;
                            drAdd["OrderUnit"] = drRecipeUnit["OrderUnit"];
                            drAdd["Rate"] = drRecipeUnit["Rate"];
                            drAdd["IsDefault"] = drRecipeUnit["IsDefault"];
                            drAdd["UnitType"] = drRecipeUnit["UnitType"];

                            dataTable.Rows.Add(drAdd);
                        }
                    }
                }
            }

            Session["dsProductEdit"] = dsProductEdit;
        }

        protected void chk_DefaultR_CheckedChanged1(object sender, EventArgs e)
        {
            var chk_DefaultR = sender as CheckBox;
            if (chk_DefaultR != null)
            {
                var selectedRow = chk_DefaultR.Parent.Parent as GridViewRow;

                for (var j = 0; j <= grd_RecipeUnit.Rows.Count - 1; j++)
                {
                    //CheckBox chk_Default        = grd_RecipeUnit.Rows[j].FindControl("chk_Default") as CheckBox;
                    var Img_Btn_ChkBox = grd_RecipeUnit.Rows[j].FindControl("Img_Btn_ChkBox") as ImageButton;
                    var lbl_ReciRate = grd_RecipeUnit.Rows[j].FindControl("lbl_ReciRate") as Label;
                    var lbl_ReciUnit = grd_RecipeUnit.Rows[j].FindControl("lbl_ReciUnit") as Label;
                    var ddl_ReciUnit = grd_RecipeUnit.Rows[j].FindControl("ddl_ReciUnit") as DropDownList;
                    var txt_ReciRate = grd_RecipeUnit.Rows[j].FindControl("txt_ReciRate") as TextBox;

                    if (selectedRow != null && j != selectedRow.RowIndex)
                    {
                        //chk_Default.Checked = false;
                        if (Img_Btn_ChkBox != null)
                        {
                            Img_Btn_ChkBox.ImageUrl = "~/App_Themes/Default/Images/IN/STDREQ/chk_False.png";
                        }

                        //dsProductEdit.Tables["RecipeUnit"].Rows[j]["IsDefault"] = false;
                    }
                    else
                    {
                        //chk_Default.Checked = true;
                        if (Img_Btn_ChkBox != null)
                        {
                            Img_Btn_ChkBox.ImageUrl = "~/App_Themes/Default/Images/IN/STDREQ/chk_True.png";
                        }

                        if (lbl_ReciUnit != null)
                        {
                            txt_RecipeUnit.Text = lbl_ReciUnit.Text;
                            if (lbl_ReciRate != null) txt_RecipeConverseRate.Text = lbl_ReciRate.Text;
                        }
                        else
                        {
                            if (ddl_ReciUnit != null) txt_RecipeUnit.Text = ddl_ReciUnit.SelectedValue;
                            if (txt_ReciRate != null) txt_RecipeConverseRate.Text = txt_ReciRate.Text;
                        }

                        //dsProductEdit.Tables["RecipeUnit"].Rows[j]["IsDefault"] = true;
                    }

                    //Session["dsProductEdit"] = dsProductEdit;
                }
            }
        }

        #region "View"

        protected void btn_ViewGo_Click(object sender, EventArgs e)
        {
            Page_Retrieve();
        }

        #endregion

        #region "grd_Unit"

        /// <summary>
        ///     Re-binding Unit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grd_Unit_OnLoad(object sender, EventArgs e)
        {
            if (dsUnit != null && dsUnit.Tables.Count > 0 && dsUnit.Tables[unit.TableName].Rows.Count > 0)
                grd_Unit.DataSource = dsUnit.Tables[unit.TableName];
            grd_Unit.DataBind();
        }

        /// <summary>
        ///     Assign Default Value for New Unit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grd_Unit_InitNewRow(object sender, DevExpress.Web.Data.ASPxDataInitNewRowEventArgs e)
        {
            e.NewValues["UnitCode"] = string.Empty;
            e.NewValues["Name"] = string.Empty;
            e.NewValues["IsActived"] = true;
            e.NewValues["CreatedBy"] = LoginInfo.LoginName;
            e.NewValues["CreatedDate"] = ServerDateTime;
            e.NewValues["UpdatedBy"] = LoginInfo.LoginName;
            e.NewValues["UpdatedDate"] = ServerDateTime;
        }

        /// <summary>
        ///     Create New Unit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grd_Unit_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            var drInserting = dsUnit.Tables[unit.TableName].NewRow();

            drInserting["UnitCode"] = e.NewValues["UnitCode"].ToString();
            drInserting["Name"] = e.NewValues["Name"].ToString();
            drInserting["IsActived"] = e.NewValues["IsActived"].ToString();
            drInserting["CreatedBy"] = LoginInfo.LoginName;
            drInserting["CreatedDate"] = ServerDateTime;
            drInserting["UpdatedBy"] = LoginInfo.LoginName;
            drInserting["UpdatedDate"] = ServerDateTime;

            dsUnit.Tables[unit.TableName].Rows.Add(drInserting);

            // Save to database
            var saveUnit = unit.Save(dsUnit, hf_ConnStr.Value);

            if (saveUnit)
            {
                grd_Unit.DataSource = dsUnit.Tables[unit.TableName];
                grd_Unit.CancelEdit();
                grd_Unit.DataBind();

                e.Cancel = true;

                Session["dsUnit"] = dsUnit;
            }
            else
            {
                // Display Error Message    
                dsUnit.Tables[unit.TableName].RejectChanges();
                grd_Unit.CancelEdit();

                e.Cancel = true;
            }
        }

        /// <summary>
        ///     Save Existing Unit Changed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grd_Unit_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            var drUpdating = dsUnit.Tables[unit.TableName].Rows[grd_Unit.EditingRowVisibleIndex];

            drUpdating["Name"] = e.NewValues["Name"].ToString();
            drUpdating["IsActived"] = e.NewValues["IsActived"].ToString();
            drUpdating["UpdatedBy"] = LoginInfo.LoginName;
            drUpdating["UpdatedDate"] = ServerDateTime;

            // Save to database
            var saveUnit = unit.Save(dsUnit, hf_ConnStr.Value);

            if (saveUnit)
            {
                grd_Unit.DataSource = dsUnit.Tables[unit.TableName];
                grd_Unit.CancelEdit();
                grd_Unit.DataBind();

                e.Cancel = true;

                Session["dsUnit"] = dsUnit;
            }
            else
            {
                // Display Error Message    
                dsUnit.Tables[unit.TableName].RejectChanges();
                grd_Unit.CancelEdit();

                e.Cancel = true;
            }
        }

        #endregion

        #region "grd_InventoryUnit"

        /// <summary>
        ///     Create New Unit
        /// </summary>
        private void CreateInventoryUnit()
        {
            grd_InventoryUnit.AddNewRow();
            //Mdlp_InventoryUnitPopup.Show();
        }

        /// <summary>
        ///     Display confrim delete Unit
        /// </summary>
        private void DeleteInventoryUnit()
        {
            if (grd_InventoryUnit.Selection.Count > 0)
            {
                //Mdlp_InventoryUnitPopup.Show();
                pop_ConfrimDeleteInventoryUnit.ShowOnPageLoad = true;
            }
        }

        /// <summary>
        /// </summary>
        /// <param name="source"></param>
        /// <param name="e"></param>
        protected void menuInventoryUnit_ItemClick(object source, DevExpress.Web.ASPxMenu.MenuItemEventArgs e)
        {
            switch (e.Item.Text.ToUpper())
            {
                case "CREATE":
                    CreateInventoryUnit();
                    break;

                case "DELETE":
                    DeleteInventoryUnit();
                    break;

                case "CLOSE":
                    //Mdlp_RecipeUnitPopup.Hide();
                    break;
            }
        }

        /// <summary>
        ///     Re-binding Unit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grd_InventoryUnit_OnLoad(object sender, EventArgs e)
        {
            if (dsUnit != null && dsUnit.Tables.Count > 0 && dsUnit.Tables[unit.TableName].Rows.Count > 0)
            {
                grd_InventoryUnit.DataSource = dsUnit.Tables[unit.TableName];
                grd_InventoryUnit.DataBind();
            }
        }

        /// <summary>
        ///     Assign Default Value for New Unit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grd_InventoryUnit_InitNewRow(object sender, DevExpress.Web.Data.ASPxDataInitNewRowEventArgs e)
        {
            e.NewValues["UnitCode"] = string.Empty;
            e.NewValues["Name"] = string.Empty;
            e.NewValues["IsActived"] = true;
            e.NewValues["CreatedBy"] = LoginInfo.LoginName;
            e.NewValues["CreatedDate"] = ServerDateTime;
            e.NewValues["UpdatedBy"] = LoginInfo.LoginName;
            e.NewValues["UpdatedDate"] = ServerDateTime;
        }

        /// <summary>
        ///     Create New Unit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grd_InventoryUnit_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            var drInserting = dsUnit.Tables[unit.TableName].NewRow();

            drInserting["UnitCode"] = e.NewValues["UnitCode"].ToString();
            drInserting["Name"] = e.NewValues["Name"].ToString();
            drInserting["IsActived"] = e.NewValues["IsActived"].ToString();
            drInserting["CreatedBy"] = LoginInfo.LoginName;
            drInserting["CreatedDate"] = ServerDateTime;
            drInserting["UpdatedBy"] = LoginInfo.LoginName;
            drInserting["UpdatedDate"] = ServerDateTime;

            dsUnit.Tables[unit.TableName].Rows.Add(drInserting);

            // Save to database
            var saveUnit = unit.Save(dsUnit, hf_ConnStr.Value);

            if (saveUnit)
            {
                grd_InventoryUnit.DataSource = dsUnit.Tables[unit.TableName];
                grd_InventoryUnit.CancelEdit();
                grd_InventoryUnit.DataBind();

                e.Cancel = true;

                Session["dsUnit"] = dsUnit;
            }
            else
            {
                // Display Error Message    
                dsUnit.Tables[unit.TableName].RejectChanges();
                grd_InventoryUnit.CancelEdit();

                e.Cancel = true;
            }
        }

        /// <summary>
        ///     Save Existing Unit Changed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grd_InventoryUnit_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            var drUpdating = dsUnit.Tables[unit.TableName].Rows[grd_InventoryUnit.EditingRowVisibleIndex];

            drUpdating["Name"] = e.NewValues["Name"].ToString();
            drUpdating["IsActived"] = e.NewValues["IsActived"].ToString();
            drUpdating["UpdatedBy"] = LoginInfo.LoginName;
            drUpdating["UpdatedDate"] = ServerDateTime;

            // Save to database
            var saveUnit = unit.Save(dsUnit, hf_ConnStr.Value);

            if (saveUnit)
            {
                grd_InventoryUnit.DataSource = dsUnit.Tables[unit.TableName];
                grd_InventoryUnit.CancelEdit();
                grd_InventoryUnit.DataBind();

                e.Cancel = true;

                Session["dsUnit"] = dsUnit;
            }
            else
            {
                // Display Error Message    
                dsUnit.Tables[unit.TableName].RejectChanges();
                grd_InventoryUnit.CancelEdit();

                e.Cancel = true;
            }
        }

        /// <summary>
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btn_ConfrimDeleteInventoryUnit_Click(object sender, EventArgs e)
        {
            var columnValues = grd_InventoryUnit.GetSelectedFieldValues("UnitCode");

            foreach (DataRow drDeleting in dsUnit.Tables[unit.TableName].Rows)
            {
                if (drDeleting.RowState != DataRowState.Deleted)
                {
                    if (drDeleting["UnitCode"].ToString().ToUpper() == columnValues[0].ToString().ToUpper())
                    {
                        drDeleting.Delete();
                    }
                }
            }

            // Save to database
            var saveUnit = unit.Save(dsUnit, hf_ConnStr.Value);

            if (saveUnit)
            {
                pop_ConfrimDeleteInventoryUnit.ShowOnPageLoad = false;

                CheckDeletedRow(columnValues[0].ToString());

                RefreshUnitDataBinding();

                Page_Retrieve();
            }
        }

        /// <summary>
        ///     RefreshUnitDataBinding
        /// </summary>
        protected void RefreshUnitDataBinding()
        {
            //cmb_OrderUnit.ValueField        = "UnitCode";
            //cmb_OrderUnit.TextField         = "UnitCode";
            //cmb_OrderUnit.TextFormatString  = "{0}";
            //cmb_OrderUnit.DataSource        = unit.GetUnitLookup(hf_ConnStr.Value);
            //cmb_OrderUnit.DataBind();

            //MAi
            //cmb_InventoryUnit.ValueField = "UnitCode";
            //cmb_InventoryUnit.TextField = "UnitCode";
            //cmb_InventoryUnit.TextFormatString = "{0}";
            //cmb_InventoryUnit.DataSource = unit.GetUnitLookup(hf_ConnStr.Value);
            //cmb_InventoryUnit.DataBind();


            //cmb_RecipeUnit.ValueField = "UnitCode";
            //cmb_RecipeUnit.TextField = "UnitCode";
            //cmb_RecipeUnit.TextFormatString = "{0}";
            //cmb_RecipeUnit.DataSource = unit.GetUnitLookup(hf_ConnStr.Value);
            //cmb_RecipeUnit.DataBind();
        }

        /// <summary>
        ///     Poup confirm dialogue closed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btn_ConfrimDeleteInventoryUnitNo_Click(object sender, EventArgs e)
        {
            grd_InventoryUnit.Selection.UnselectAll();
            pop_ConfrimDeleteInventoryUnit.ShowOnPageLoad = false;
        }

        #endregion

        #region "grd_Orderunit"

        /// <summary>
        ///     Create New Unit
        /// </summary>
        private void CreateOrderunit()
        {
            grd_Orderunit.AddNewRow();
            //Mdlp_OrderunitPopup.Show();
        }

        /// <summary>
        ///     Display confrim delete Unit
        /// </summary>
        private void DeleteOrderunit()
        {
            if (grd_Orderunit.Selection.Count > 0)
            {
                //Mdlp_OrderunitPopup.Show();
                pop_ConfrimDeleteOrderunit.ShowOnPageLoad = true;
            }
        }

        /// <summary>
        /// </summary>
        /// <param name="source"></param>
        /// <param name="e"></param>
        protected void menuOrderunit_ItemClick(object source, DevExpress.Web.ASPxMenu.MenuItemEventArgs e)
        {
            switch (e.Item.Text.ToUpper())
            {
                case "CREATE":
                    CreateOrderunit();
                    break;

                case "DELETE":
                    DeleteOrderunit();
                    break;

                case "CLOSE":
                    //Mdlp_RecipeUnitPopup.Hide();
                    break;
            }
        }

        /// <summary>
        ///     Re-binding Unit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grd_Orderunit_OnLoad(object sender, EventArgs e)
        {
            if (dsUnit != null && dsUnit.Tables.Count > 0 && dsUnit.Tables[unit.TableName].Rows.Count > 0)
            {
                grd_Orderunit.DataSource = dsUnit.Tables[unit.TableName];
                grd_Orderunit.DataBind();
            }
        }

        /// <summary>
        ///     Assign Default Value for New Unit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grd_Orderunit_InitNewRow(object sender, DevExpress.Web.Data.ASPxDataInitNewRowEventArgs e)
        {
            e.NewValues["UnitCode"] = string.Empty;
            e.NewValues["Name"] = string.Empty;
            e.NewValues["IsActived"] = true;
            e.NewValues["CreatedBy"] = LoginInfo.LoginName;
            e.NewValues["CreatedDate"] = ServerDateTime;
            e.NewValues["UpdatedBy"] = LoginInfo.LoginName;
            e.NewValues["UpdatedDate"] = ServerDateTime;
        }

        /// <summary>
        ///     Create New Unit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grd_Orderunit_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            var drInserting = dsUnit.Tables[unit.TableName].NewRow();

            drInserting["UnitCode"] = e.NewValues["UnitCode"].ToString();
            drInserting["Name"] = e.NewValues["Name"].ToString();
            drInserting["IsActived"] = e.NewValues["IsActived"].ToString();
            drInserting["CreatedBy"] = LoginInfo.LoginName;
            drInserting["CreatedDate"] = ServerDateTime;
            drInserting["UpdatedBy"] = LoginInfo.LoginName;
            drInserting["UpdatedDate"] = ServerDateTime;

            dsUnit.Tables[unit.TableName].Rows.Add(drInserting);

            // Save to database
            var saveUnit = unit.Save(dsUnit, hf_ConnStr.Value);

            if (saveUnit)
            {
                grd_Orderunit.DataSource = dsUnit.Tables[unit.TableName];
                grd_Orderunit.CancelEdit();
                grd_Orderunit.DataBind();

                e.Cancel = true;

                Session["dsUnit"] = dsUnit;
            }
            else
            {
                // Display Error Message    
                dsUnit.Tables[unit.TableName].RejectChanges();
                grd_Orderunit.CancelEdit();

                e.Cancel = true;
            }
        }

        /// <summary>
        ///     Save Existing Unit Changed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grd_Orderunit_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            if (Convert.ToBoolean(e.NewValues["IsActived"].ToString()))
            {
                if (dsUnit.Tables[unit.TableName].Rows.Count > 0)
                {
                    for (var jj = 0; jj < dsUnit.Tables[unit.TableName].Rows.Count; jj++)
                    {
                        var drChk = dsUnit.Tables[unit.TableName].Rows[jj];

                        if (jj != grd_Orderunit.EditingRowVisibleIndex)
                        {
                            drChk["IsActived"] = false;
                        }
                    }
                }
            }

            var drUpdating = dsUnit.Tables[unit.TableName].Rows[grd_Orderunit.EditingRowVisibleIndex];

            drUpdating["Name"] = e.NewValues["Name"].ToString();
            drUpdating["IsActived"] = e.NewValues["IsActived"].ToString();
            drUpdating["UpdatedBy"] = LoginInfo.LoginName;
            drUpdating["UpdatedDate"] = ServerDateTime;

            // Save to database
            var saveUnit = unit.Save(dsUnit, hf_ConnStr.Value);

            if (saveUnit)
            {
                grd_Orderunit.DataSource = dsUnit.Tables[unit.TableName];
                grd_Orderunit.CancelEdit();
                grd_Orderunit.DataBind();

                e.Cancel = true;

                Session["dsUnit"] = dsUnit;
            }
            else
            {
                // Display Error Message    
                dsUnit.Tables[unit.TableName].RejectChanges();
                grd_Orderunit.CancelEdit();

                e.Cancel = true;
            }
        }

        /// <summary>
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btn_ConfrimDeleteOrderunit_Click(object sender, EventArgs e)
        {
            var columnValues = grd_Orderunit.GetSelectedFieldValues("UnitCode");

            foreach (DataRow drDeleting in dsUnit.Tables[unit.TableName].Rows)
            {
                if (drDeleting.RowState != DataRowState.Deleted)
                {
                    if (drDeleting["UnitCode"].ToString().ToUpper() == columnValues[0].ToString().ToUpper())
                    {
                        drDeleting.Delete();
                    }
                }
            }

            // Save to database
            var saveUnit = unit.Save(dsUnit, hf_ConnStr.Value);

            if (saveUnit)
            {
                pop_ConfrimDeleteOrderunit.ShowOnPageLoad = false;

                CheckDeletedRow(columnValues[0].ToString());

                RefreshUnitDataBinding();

                Page_Retrieve();
            }
        }

        /// <summary>
        ///     No click process, closed poup dialogue.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btn_OrderunitNo_Click(object sender, EventArgs e)
        {
            grd_Orderunit.Selection.UnselectAll();
            pop_ConfrimDeleteOrderunit.ShowOnPageLoad = false;
        }

        #endregion

        #region "Misc"

        private DataColumn[] GetPK()
        {
            var primaryKeys = new DataColumn[1];
            primaryKeys[0] = dsUnit.Tables[unit.TableName].Columns["UnitCode"];

            return primaryKeys;
        }

        #endregion

        // Added on: 03/04/2018, By: Fon
        #region Product Location HQ
        protected bool IsBUHQActive()
        {
            bool isHQBUactive = false;
            DataSet dsBU = new DataSet();
            string hqBUcode = bu.GetHQBuCode(LoginInfo.BuInfo.BuGrpCode);

            if (hqBUcode != string.Empty) bu.GetList(dsBU, hqBUcode, System.Configuration.ConfigurationManager.AppSettings["ConnStr"].ToString());
            if (dsBU.Tables.Contains(bu.TableName))
                if (dsBU.Tables[bu.TableName].Rows.Count > 0)
                    isHQBUactive = (bool)dsBU.Tables[bu.TableName].Rows[0]["IsActived"];

            return isHQBUactive;
        }

        protected DataSet ExceptChanged_ProdLocHQ()
        {
            // Note: In ProdEdit2.aspx, not mind about location.
            // IF ( GetHQproduct != ddl_HQSKU ) loop Update.

            DataSet dsProdLocHQ = new DataSet();
            string connStringHQ = bu.GetHQConnStr(LoginInfo.BuInfo.BuGrpCode);
            string oldHQSKU = prodLocHQ.GetProductCodeHQ(Request.Params["BuCode"], txt_Code.Text, connStringHQ);
            string newHQSKU = ddl_HQSKU.Text.Split(':')[0];
            if (oldHQSKU != newHQSKU)
            {
                if (prodLocHQ.GetListByProductCodeBU(dsProdLocHQ,
                    Request.Params["BuCode"], txt_Code.Text, connStringHQ))
                {
                    foreach (DataRow dr in dsProdLocHQ.Tables[prodLocHQ.TableName].Rows)
                    {
                        dr["ProductCodeHQ"] = newHQSKU;
                    }
                }
            }

            return dsProdLocHQ;
        }
        #endregion
        // End Added.
    }
}